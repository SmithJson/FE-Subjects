// import "@babel/polyfill";

console.log('hello world!')


import  ABC from 'images/ABC.jpg';

console.log(ABC);
console.log(sceneParam)
console.log('----------')

if(sceneParam=='prod') {
    import('styles/main.less');
} else {
    import('styles/test.less');
}
// document.addEventListener('DOMContentLoaded', () => { 
//     const h1Ele = document.createElement('h1'); 
//     document.body.append(h1Ele); 
//     h1Ele.innerText = 'Hello Webpack (^_^)' 
//     h1Ele.style.color = '#f46';
// })

const arr = [new Promise(() => {}), new Promise(() => {})];
arr.map(item => {  console.log(item); });

var isCol = ['11','22'].includes('11');
console.log(isCol);