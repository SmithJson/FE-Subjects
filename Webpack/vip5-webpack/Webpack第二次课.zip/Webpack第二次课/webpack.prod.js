const webpack = require('webpack'); 
const path = require('path'); 
const merge = require('webpack-merge');
const DIST_PATH = path.resolve(__dirname, './dist/'); 
const commonConfig = require('./webpack.common.js'); 
module.exports = merge(commonConfig, { 
    // mode: 'production',
    mode:'development', 
    output: { 
        path: DIST_PATH, // 创建的bundle生成到哪里
        filename: '[name].[chunkhash:8].js', // 创建的bundle的名称
     }, 
    // 设置Webpack的mode模式 
    plugins: [ ]
})