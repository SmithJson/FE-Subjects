const webpack = require('webpack'); 
const path = require('path'); 
const merge = require('webpack-merge');
const commonConfig = require('./webpack.common.js'); 
const DIST_PATH = path.resolve(__dirname, './dist/'); 

module.exports = merge(commonConfig, { 
    mode: 'development', 
    // 设置Webpack的mode模式 
    // 开发环境下需要的相关插件配置 
    output: { 
        path: DIST_PATH, // 创建的bundle生成到哪里
        filename: '[name].js', // 创建的bundle的名称
     }, 
     
    plugins: [ ], 
     // 开发服务器 
     devServer: { 
        hot: true, // 热更新，无需手动刷新 
        contentBase: DIST_PATH,  //热启动文件所指向的文件路径
        host: '0.0.0.0', // host地址 
        port: 8080, // 服务器端口 
        historyApiFallback: true, // 该选项的作用所用404都连接到index.html 
        proxy: { 
        "/api": "http://localhost:3000" 
        // 代理到后端的服务地址，会拦截所有以api开头的请求地址
         } ,
        useLocalIp: true 
        // open:true,
        // noInfo:true
      }
})