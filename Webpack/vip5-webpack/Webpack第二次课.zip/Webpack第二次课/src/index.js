// import "@babel/polyfill";

console.log('hello world!')
import './styles/main.css';
import './styles/test.less';
import  ABC from './images/ABC.jpg';

console.log(ABC);

// document.addEventListener('DOMContentLoaded', () => { 
//     const h1Ele = document.createElement('h1'); 
//     document.body.append(h1Ele); 
//     h1Ele.innerText = 'Hello Webpack (^_^)' 
//     h1Ele.style.color = '#f46';
// })

const arr = [new Promise(() => {}), new Promise(() => {})];
arr.map(item => {  console.log(item); });

var isCol = ['11','22'].includes('11');
console.log(isCol);