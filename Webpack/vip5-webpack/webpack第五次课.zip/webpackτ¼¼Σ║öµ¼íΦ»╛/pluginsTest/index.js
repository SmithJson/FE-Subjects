console.log("hello webpack");

//写一个loader ，webpack帮我替换js文件里的某个单词
