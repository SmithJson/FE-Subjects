<template>
    <div>page2</div>
</template>