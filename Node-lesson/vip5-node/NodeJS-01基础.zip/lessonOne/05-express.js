// const express = require('express');

const express = require('./06-myexpress.js');

const app = express();
app.get('/',(req,res) => {
    res.end('Hello world')
})
app.get('/users',(req,res) => {
    res.end(JSON.stringify({name:'abcooooo'}))
})
app.get('/list',(req,res) => {
    res.end(JSON.stringify({name:'list'}))
})
app.listen2(3200 , () => {
    console.log('Example listen at 3200')
})

// const url = require('url')
// var test = url.parse('https://user:pass@sub.example.com:8080/p/a/t/h?query=string#hash');
// console.log(test);