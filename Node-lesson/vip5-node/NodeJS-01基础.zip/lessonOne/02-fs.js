const fs = require('fs');

//同步读取
// const data = fs.readFileSync('./package.json');
// console.log('data',data);
// console.log('data2',data.toString());


// //异步读取
// const data2 = fs.readFile('./package.json',function(err,data){
//     console.log('异步data',data);
//     console.log('异步data2',data.toString());
// });

//利用promise ，第一种方式
// 异步函数promise化
// function promisify(fn) {
//     return function () {
//         let args = Array.prototype.slice.call(arguments);
//         return new Promise(function (resolve, reject) {
//             args.push(function (err, result) {
//                 if (err) reject(err);
//                 else resolve(result);
//             });
//             fn.apply(null, args);
//         });
//     }
// }

// var readFile = promisify(fs.readFile);
// readFile('./package.json').then((res)=>{
//     console.log(res.toString())
// })

// v >  8 , 第二种方式
// util promisify
const {promisify} = require('util');

var readFile = promisify(fs.readFile);
// readFile('./package.json').then((res)=>{
//     console.log(res.toString())
// });

( async ()=>{
    // var data3 = await fs.readFile('./package.json'); //可以吗，不可以的,需要一个promise对象,
    var data3 = await readFile('./package.json'); // 可以
    console.log('ppp',data3)
})();


