const http = require('http');
const url = require('url');
let routers = [];
class Application {
    get(path,hander){
        routers.push({
            path,
            method:'get',
            hander
        });
    }
    listen2(){
        const server = http.createServer(function(req,res){
            const {pathname} = url.parse(req.url,true);
            //在路由表routers通过pathname，找到回调，然后执行

            // var test = routers.filter((v)=>{
            //     return  v.path == pathname && req.method.toLowerCase()==v.method
            // })[0].hander(req,res)
            
           var tet = routers.find(v=>{
                return  v.path == pathname && req.method.toLowerCase()==v.method
            })
            
            tet && tet.hander(req,res); 

         })
         //在Application原型上添加listen方法匹配路径， 执行对应的hander
         server.listen(...arguments)
        //  server.listen(aa,fn)
    }
}
module.exports = function(){
    return new Application();
}

// const url = require('url');
// var test = url.parse('https://user:pass@sub.example.com:8080/p/a/t/h?query=string#hash');
// console.log(test);