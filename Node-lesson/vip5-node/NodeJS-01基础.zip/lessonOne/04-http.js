const http = require('http');
const fs = require('fs');
//request
//response
http.createServer(function(request,response){
    const {url,method,headers} = request;
    
    if(url=='/' && method=='GET'){
        fs.readFile('index.html', (err, data) => {
            if (err) {
                response.writeHead(500, { 'Content-Type': 'text/pain;charset=utf-8' });
                response.end('服务器错误');
                return;
            }
            response.statusCode = 200;
            response.setHeader('Content-Type', 'text/html');
            response.end(data);
        })
    } else if (url == '/users' && method === 'GET') {
        response.statusCode = 200
        response.setHeader('Content-Type', 'text/html')
        response.end(JSON.stringify({ name: 'laney' }))
    }

    else if (url == '/list' && method === 'GET') {
        response.statusCode = 200
        response.setHeader('Content-Type', 'text/html')
        response.end(JSON.stringify({ name: 'sss' }))
    }
}).listen(3000,function(){
    console.log('监听到3000');
});

// const routes= [];

// routes.get({
//     path:'',
//     method:'',
//     fn(){

//     }
// })

