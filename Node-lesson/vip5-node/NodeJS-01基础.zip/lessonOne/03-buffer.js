const buf01 = Buffer.alloc(10);
console.log(buf01.toString())
const buf02 = Buffer.from([10,20,30]);
console.log(buf02.toString())

const buf03 = Buffer.from('创建方法');

buf03.write('hellouuuuuuu');
console.log(buf03.toString())  //从缓冲区读取数据

var mn = Buffer.concat([buf01,buf02]);

console.log(mn) 

