const Header = require('./header')
import Content from './content'
import Footer from './footer'


new Header()
new Content()
new Footer()
