function Footer(){
    var dom = document.getElementById('root')
    let footer = document.createElement('div')
    footer.innerText = 'footer'
    dom.append(footer)
}
export default Footer