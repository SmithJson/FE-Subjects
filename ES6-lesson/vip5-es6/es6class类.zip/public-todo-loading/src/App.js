import React from 'react';
import Add from './components/add'
import List from './components/list'
class App extends React.Component{
  constructor(props){
    super(props)
    this.state = {
      list:[
        '吃饭',
        '睡觉',
        '运动',
        '打游戏',
      ],
      aaa:333,
      bbb:444
    }
  }
  add = (value)=>{
    const {list} = this.state;
    list.unshift(value)
    this.setState({list}) // 非常非常重要的
  }
  render(){
    const {list} = this.state;
    // 获取list的length
    // const length = this.state.list.length;
    return (
      <div>
        <Add add={this.add} length={list.length}/>
        <List alllist = {list}/>
      </div>
    );
  }
}
export default App;
