import React from 'react';


export default function Ui(){
    return (
        <div>
            <p>我是简单组件</p>
            <input type="text" />
        </div>
    )
}