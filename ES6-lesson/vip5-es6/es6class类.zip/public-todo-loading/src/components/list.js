import React from 'react';
class List extends React.Component{
  render(){
      const {alllist} = this.props
    return (
      <div>
        <ul>
          {
              alllist.map((v,i)=>
                 <li key={i}>{v}</li>
              )
          }
        </ul>
      </div>
    );
  }
}
export default List;
