import React from 'react';
class Add extends React.Component{
    constructor(props){
      super(props)
      this.addClick = this.addClick.bind(this)
    }
    // addClick = ()=>{
    //     // alert(123)
    //     // console.log(this.uuu.value);
    //     // console.log(this.props);
    //     // 操作父组件传过来的函数
    //     this.props.add(this.uuu.value)
    //     // 要让input框的值为空
    //     this.uuu.value = ''
    // }
    addClick (){
      // alert(123)
      // console.log(this.uuu.value);
      // console.log(this.props);
      // 操作父组件传过来的函数
      this.props.add(this.uuu.value)
      // 要让input框的值为空
      this.uuu.value = ''
  }
  render(){
    //   console.log(this.props.length);
      const {length} = this.props;
    return (
      <div>
        <input type="text" ref={(iii)=>{this.uuu = iii}}/>
        <button onClick={this.addClick}>添加#{length}</button>
      </div>
    );
  }
}
export default Add;
