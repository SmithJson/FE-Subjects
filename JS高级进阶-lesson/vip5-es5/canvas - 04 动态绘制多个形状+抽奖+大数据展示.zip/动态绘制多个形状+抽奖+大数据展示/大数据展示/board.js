
//画顶部折现
function drawLayerLabel(canvasObj,textInfo){
	// text,textBeginX,lineEndX
	var text = textInfo.text,
		textBeginX =60,
		lineEndX = textInfo.lineWid,
		colorValue = '#04918B';
	canvasObj.width = lineEndX;
	var ctx = canvasObj.getContext("2d");
	//控制整体的颜色
	ctx.fillStyle = colorValue;
	//小点实心圆
	ctx.beginPath();
	ctx.arc(35,55,2,0,2*Math.PI); 
	ctx.fill();

	//画折线
	ctx.moveTo(35,55);
	ctx.lineTo(60,80);
	ctx.lineTo(lineEndX,80);
	ctx.lineWidth = 1;
	ctx.strokeStyle = colorValue;
	ctx.stroke();

	//画文字
	ctx.font='12px Georgia';
	ctx.fillText(text,textBeginX,92);
}


//接入机型占比
function modelTypeFun(){
    // 基于准备好的dom，
   var modelTypeChart = document.getElementById('modelTypeDom');
   // 初始化echarts实例
   var myChart = echarts.init(modelTypeChart);
   var COLOR = {
       MACHINE:{
           TYPE_A:'#0175EE',
           TYPE_B:'#D89446',
           TYPE_C:'#373693',
           TYPE_D:'#25AE4F',
           TYPE_E:'#06B5C6',
           TYPE_F:'#009E9A',
           TYPE_G:'#AC266F'
       }
   };

var option = {
   title : {
       text: '接入机型占比',
       textStyle:{
           color:'#fff'
       },
       subtext: '模拟',
       x:'left'
   },
   tooltip : {
       trigger: 'item',
       formatter: "{a} <br/>{b} : {c} ({d}%)"
   },
   legend: {
       orient: 'vertical',
       left: 'left',
       top:'50',
       itemGap:15,
       icon:'circle',
       textStyle:{
           color:'#fff'
       },
       data:['A机型','B机型','C机型','D机型','E机型','F机型','G机型']
   },
   color:[COLOR.MACHINE.TYPE_A,COLOR.MACHINE.TYPE_B,COLOR.MACHINE.TYPE_C,COLOR.MACHINE.TYPE_D,COLOR.MACHINE.TYPE_E,COLOR.MACHINE.TYPE_F,COLOR.MACHINE.TYPE_G],
   series : [
       {
           name: '访问来源',
           type: 'pie',
           radius : '55%',
           center: ['50%', '50%'],
           // roseType : 'area',
           data:[
               {value:4600, name:'A机型',
               //   itemStyle:{
               //       color:'red'
               //   },
                  emphasis:{
                      label:{
                          fontSize:30
                      }
                  }
               },
               {value:4600, name:'B机型'},
               {value:15600, name:'C机型'},
               {value:6600, name:'D机型'},
               {value:5700, name:'E机型'},
               {value:7600, name:'F机型'},
               {value:3500, name:'G机型'}
           ],
           itemStyle: {
               emphasis: {
                   shadowBlur: 10,
                   shadowOffsetX: 0,
                   shadowColor: 'rgba(0, 0, 0, 0.5)'
               }
           }
       }
   ]
};

myChart.setOption(option);
}

// 存储 
function drawStorage(canvasId,colorValue,rate){
    var canvasDom = document.getElementById(canvasId);
    var ctx = canvasDom.getContext("2d");
    
	var circle = {
       	 	x : 65,    //圆心的x轴坐标值
        	y : 80,    //圆心的y轴坐标值
       	 	r : 60      //圆的半径
    	};

	//画阴影圆
	ctx.beginPath();
	ctx.arc(circle.x,circle.y,circle.r,0,Math.PI*2)
	ctx.lineWidth = 10;
	ctx.strokeStyle = '#052639';
	ctx.stroke();
	ctx.closePath();

	//画百分比圆
    ctx.beginPath();
	ctx.arc(circle.x,circle.y,circle.r,0,2 * rate * Math.PI,false)
	ctx.lineWidth = 10;
	ctx.lineCap = 'round';
	ctx.strokeStyle = colorValue;
	ctx.stroke();
	ctx.closePath();
    
	ctx.fillStyle = 'white';
	ctx.font = '20px Calibri';

	   //渲染文本
       // fillText(text, x,y, maxWidth)
	   // strokeText(text, x,y, maxWidth)
			
	ctx.fillText(rate*100+'%',circle.x-15,circle.y+10);
}


//30天日均线流量趋势
function getLatestDays(num){
	var currentDay = new Date();
	var returnDays = [];
	for (var i = 0 ; i < num ; i++)
	{
		currentDay.setDate(currentDay.getDate() - 1);
		returnDays.push((currentDay.getMonth()+1)+"/"+currentDay.getDate());
	}
	return returnDays;
}
function renderTrendFlow(){
	var myChart = echarts.init(document.getElementById("trendFlowDom"));
	myChart.setOption(
		{
			title: {
				text: ''
			},
			tooltip : {
				trigger: 'axis'
			},
			legend: {
				data:[]
			},
			grid: {
				left: '3%',
				right: '4%',
				bottom: '5%',
				top:'4%',
				containLabel: true
			},
			xAxis :
			{
				type : 'category',
				boundaryGap : false,
				data : getLatestDays(31),
				axisLabel:{
					textStyle:{
						color:"white", //刻度颜色
						fontSize:8  //刻度大小
					},
					rotate:45,
					interval:2
				},
				axisTick:{show:false},
				axisLine:{
					show:true,
					lineStyle:{
						color: '#0B3148',
						width: 1,
						type: 'solid'
					}
				}
			},
			yAxis : 
			{
				type : 'value',
				// 坐标轴刻度相关设置
				axisTick:{show:false},
				// axisLabel 坐标轴刻度标签的相关设置。
				axisLabel:{
					textStyle:{
						color:"white", //刻度颜色
						fontSize:8  //刻度大小
						}
				},
				axisLine:{
					show:true,
					lineStyle:{
						color: '#0B3148',
						width: 1,
						type: 'solid'
					}
				},
				splitLine:{
					show:false
				}
			},
			tooltip:{
				formatter:'{c}',
				backgroundColor:'#FE8501'
			},
			series : [
				{
					name:'',
					type:'line',
					smooth:true, //是否是弧线
					// 填充的颜色,除了纯色之外颜色也支持渐变色和纹理填充
					areaStyle:{
						color: {
							type: 'linear',
							x: 0,
							y: 0,
							x2: 0,
							y2: 1,
							colorStops: [{
								offset: 0, color: 'red' // 0% 处的颜色
							}, {
								offset: 1, color: 'blue' // 100% 处的颜色
							}],
							global: false // 缺省为 false
						},
						opacity:0.3
					},
					// areaStyle:{
					// 	normal:{
					// 		color:new echarts.graphic.LinearGradient(0, 0, 0, 1, [{offset: 0, color: '#026B6F'}, {offset: 1, color: '#012138' }], false),
					// 		opacity:0.2
					// 	}
					// },
					//折线拐点标志的样式
					itemStyle : {  
						color:'#009991',
						opacity:1
					},
					lineStyle:{
						color:'#009895',
						opacity:0.3
					},
					//标记的图形
					// ECharts 提供的标记类型包括 'circle', 'rect', 'roundRect', 
					// 'triangle', 'diamond', 'pin', 'arrow', 'none'
// 可以通过 'image://url' 设置为图片，其中 URL 为图片的链接，或者 dataURI。
					symbol:'diamond',
					data:[48, 52, 45, 46, 89, 120, 110,100,88,96,88,45,78,67,89,103,104,56,45,104,112,132,120,110,89,95,90,89,102,110,110]
				}
			]
		}
	
	);
}

//集群性能
function renderCluster(){
	var myChart = echarts.init(document.getElementById("clusterDom"));
	myChart.setOption({
			title: {
				text: ''
			},
			tooltip: {
				trigger: 'axis'
			},
			legend: {
				top:20,
				right:5,
				textStyle:{
					color:'white'
				},
				orient:'vertical',
				icon:'circle',
				data:[
						{name:'网络'},
						{name:'内存'},
						{name:'CPU'}
					]
			},
			grid: {
				left: '5%',
				right: '15%',
				bottom: '6%',
				top:'3%',
				containLabel: true
			},
			xAxis: {
				type: 'category',
				boundaryGap: false,  //第一个点是否从横坐标为0 开开始
				axisTick:{show:false},
				axisLabel:{
					textStyle:{
						color:"white", //刻度颜色
						fontSize:8  //刻度大小
					}
				},
				axisLine:{
					show:true,
					lineStyle:{
						color: '#0B3148',
						width: 1,
						type: 'solid'
					}
				},
				data: get10MinutesScale()
			},
			yAxis: {
				type: 'value',
				axisTick:{show:false},
				axisLabel:{
					textStyle:{
						color:"white", //刻度颜色
						fontSize:8  //刻度大小
						}
				},
				axisLine:{
					show:true,
					lineStyle:{
						color: '#0B3148',
						width: 1,
						type: 'solid'
					}
				},
				//y轴方向的标识线
				splitLine:{
					show:false
				}
			},
			series: [
						{
							name:'网络',
							type:'line',
							itemStyle:{
								color:'#F3891B'
							},
							lineStyle:{
								color:'#F3891B',
								opacity:1
							},
							data:[120, 132, 101, 134, 90, 230, 210]
						},
						{
							name:'内存',
							type:'line',
							itemStyle:{
								color:'#006AD4'
							},
							lineStyle:{
								color:'#F3891B',
								opacity:1
							},
							data:[220, 182, 191, 234, 290, 330, 310]
						},
						{
							name:'CPU',
							type:'line',
							itemStyle:{
								color:'#009895'
							},
							lineStyle:{
								color:'#009895',
								opacity:1
							},
							data:[150, 232, 201, 154, 190, 330, 410]
						}
					]
		}	
	);
}

function get10MinutesScale()
{
	var currDate = new Date(),
		minO = currDate.getMinutes();	

	var odd = minO%10;
	var returnArr = new Array();
	currDate.setMinutes(minO-odd);

	for(var i = 0; i <7; i++){
		var hour = currDate.getHours();
		var min = currDate.getMinutes();
		console.log(min);
		returnArr.push(hour+":"+(min<10?("0"+min):min));
		currDate.setMinutes(min-10); //改变分
	}
	return returnArr;
}
