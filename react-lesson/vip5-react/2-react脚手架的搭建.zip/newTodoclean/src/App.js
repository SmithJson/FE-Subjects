import React from 'react'
import TodoMain from './components/TodoMain';
import TodoHeader from './components/TodoHeader';
import TodoFooter from './components/TodoFooter';
class App extends React.Component{
   constructor(props){
    super(props)
    this.state = {
      todos:[],
      isAllChecked:false
    }
   }
    addTodo = (todoItem)=>{
      this.state.todos.push(todoItem)
      // 
      this.setState({
        todos:this.state.todos
      })
    }
    deleteTodo = (index)=>{
      this.state.todos.splice(index,1)
      this.setState({
        todos:this.state.todos
      })
    }
    changeTodoState = (index,isDone)=>{
      this.state.todos[index].isDone = isDone
      let isAllChecked = false
      if(this.state.todos.every(todo=>todo.isDone)){
        isAllChecked = true
      }
      this.setState({
        todos:this.state.todos,
        isAllChecked
      })
    }
    changeTodoStateAll = (isDone) =>{
      this.setState({
        todos:this.state.todos.map((todo)=>{
          todo.isDone = isDone;
          return todo
        }),
        isAllChecked:isDone
      })
    }
    clearDone = ()=>{
      // 
      let todos = this.state.todos.filter(todo=>!todo.isDone)
      this.setState({
        todos,
        isAllChecked:false
      })
    }
    render(){
        const {todos,isAllChecked} = this.state;
        let info = {
          todoCount:todos.length || 0,
          todos,
          todoDoneCount:(todos && todos.filter((todo)=>todo.isDone)).length || 0,
          isAllChecked
        } 
        return(
          <div className="todo-wrap">
                <TodoHeader addTodo = {this.addTodo}/>
                <TodoMain {...info} deleteTodo = {this.deleteTodo} changeTodoState={this.changeTodoState}/>
                <TodoFooter {...info} changeTodoStateAll={this.changeTodoStateAll} clearDone={this.clearDone}/>
          </div>
        );
    }
}
export default App;