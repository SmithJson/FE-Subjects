import React from 'react';
class TodoHeader extends React.Component{
    handelKeyUp = (e)=>{
        // 获取input的值
        if(e.keyCode == 13){
            let value = e.target.value;
            if(!value) return false
            let newTodoItem = {
                text:value,
                isDone:false
            }
            e.target.value = ''
            // 调用父组件传过来的方法
            this.props.addTodo(newTodoItem)
        }
        
    }
    render() {
        return(
            <div className="todo-header">
                <h1 className="text-center">React Todo</h1>
                <div className="form-horizontal">
                    <div className="form-group">
                    <label className="col-md-2 control-label">Task</label>
                    <div className="col-md-10">
                      <input type="text" onKeyUp={this.handelKeyUp} placeholder="请输入你的任务名称，按回车键确认" className="form-control"/>
                    </div>
                    </div>
                </div>
            </div>
        )
    }
};
export default TodoHeader;