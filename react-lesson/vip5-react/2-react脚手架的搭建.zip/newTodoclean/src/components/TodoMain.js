import React from 'react';
import TodoItem from './TodoItem';
export default  class TodoMain extends React.Component{
    render() {
        const {todos,todoCount,todoDoneCount} = this.props
        if(todos.length == 0){
            return <div class="todo-empty">
                恭喜你没有代办事项
            </div>
        }else{
            return (
                <ul className="todo-main">
                    {
                        todos.map((todo,index)=>{
                            return <TodoItem  text={todo.text} key={index} isDone={todo.isDone} index={index} {...this.props}/>
                        })
                    }
                    <li className="item">
                        <label>
                          <span><strong>{todoCount}</strong>总数/<strong>{todoDoneCount}</strong>已完成</span>
                        </label>
                    </li>
                </ul>
            )
        }
             
    }
}