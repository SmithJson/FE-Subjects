import React from 'react';
export default class TodoItem extends React.Component{
    state = {
        isShow:false
    }
    handelMouseOver = ()=>{
        this.setState({
            isShow:true
        })
    }
    handelMouseOut = ()=>{
        this.setState({
            isShow:false
        })
    }
    handelDelete = ()=>{
        this.props.deleteTodo(this.props.index)
    }
    handelChange = ()=>{
        let isDone = !this.props.isDone;
        this.props.changeTodoState(this.props.index,isDone)
    }
    render(){
        const {isShow} = this.state
        const {text,isDone} = this.props
        const taskDone = isDone ? "task-done" : ''
        return(
            <li className="list-group-item-success item" onMouseOver={this.handelMouseOver} onMouseOut={this.handelMouseOut}>
                 <label>
                     <input type="checkbox" checked={this.props.isDone}className="pull-left" onChange={this.handelChange}/>
                     <span className={taskDone}>{text}</span>
                 </label>
                <div className="pull-right">
                    <button type="button" className={isShow ? "btn btn-xs" : "btn btn-xs close"} onClick={this.handelDelete}>删除</button>
                </div>
            </li>
        )
    }
}