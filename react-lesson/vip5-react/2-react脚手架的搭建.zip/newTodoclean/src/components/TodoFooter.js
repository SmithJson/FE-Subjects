import React from 'react';
export default class TodoFooter extends React.Component{
    handelSelectAll = (e)=>{
        this.props.changeTodoStateAll(e.target.checked)
    }
    handelDeleteDone = ()=>{
        this.props.clearDone()
    }
    render(){
            return(
                <div className="todo-footer">
                    <label>
                        <input type="checkbox"  checked={this.props.isAllChecked} onChange={this.handelSelectAll}/>全选
                    </label>
                    <div className="clearTask">
                        <button className="btn" onClick={this.handelDeleteDone}>清除已完成任务</button>
                    </div>
                </div>
            )
    }
}