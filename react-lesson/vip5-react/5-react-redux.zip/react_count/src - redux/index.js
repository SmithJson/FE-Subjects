import React from 'react'
import ReactDOM from 'react-dom'
import {createStore} from 'redux'
import App from './components/app'
import {counter} from './redux/reducers'
const common = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__
const store = createStore(counter,common())


const render = ()=>{
    ReactDOM.render(<App store={store}/>, document.getElementById('root'))
}
// 初始化渲染
render()

// 注册监听
store.subscribe(render)
