import jsonP from 'jsonp'

export default class Axios {
    static jsonP(options){
        return new Promise((resolve,reject)=>{
            jsonP(options.url,{
                params:"callback"
            },function(error,response){
                if(response.status == 'success'){
                    resolve(response)
                }else{
                    reject(response.message)
                }
            })
        })
    }
}