import React from 'react';
import './index.less'
class Footer extends React.Component{
  render(){
    return(
         <div className="footer">
            版权归软谋教育所有
         </div>
    )
  }
}

export default Footer;
