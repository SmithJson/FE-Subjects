import axios from 'axios'
const GET_LIST = 'INDEX/GET_LIST'

// action 

const changeList = list => ({
    type:GET_LIST,
    list
})

// 有一个请求 可以改变reducer

export const getIndexList = ()=>{
    return (dispatch)=>{
        return axios.get('http://localhost:1002/course/list').then((res)=>{
            const {list} = res.data
            dispatch(changeList(list))
        })
    }
}
const initState = {
    list:[]
}
export default (state = initState,action) => {
    switch(action.type){
        case GET_LIST:
        const newState = {
            ...state,
            list:action.list
        }
        return newState
        default:
            return state
    }
}