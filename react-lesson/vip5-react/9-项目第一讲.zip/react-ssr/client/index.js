import React from 'react'
import ReactDOM from 'react-dom'
import {BrowserRouter} from 'react-router-dom'
import {Provider} from 'react-redux'
import {getClientStore} from '../store/store'
import {Route,Link} from 'react-router-dom'
import routers from '../router'

const store = getClientStore()
const App = ()=>{
    return (
        <Provider store={store}>
            <BrowserRouter>
                <div>
                    <Link to="/">首页</Link>
                    <Link to="/login">登录</Link>
                </div>
                {routers.map(route=><Route {...route}/>)}
            </BrowserRouter>
        </Provider>
    )
}
ReactDOM.hydrate(
    <App/>
    ,document.getElementById('root'))