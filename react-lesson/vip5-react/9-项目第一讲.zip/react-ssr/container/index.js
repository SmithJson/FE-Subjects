import React ,{useState} from 'react'
import {connect} from 'react-redux'
import {getIndexList} from '../store/index'
const Index = (props) => {
    let [count,setCount] = useState(1)
    return (
        <div>
            <h1>软谋教育</h1>
            <h1>{count}</h1>
            <button onClick={()=>{props.getIndexList()}}>加载</button>
            <button onClick={()=>{setCount(count+1)}}>增加</button>
            {
                props.list.map(item=><li key={item.id}>{item.name}</li>)
            }
        </div>
    )
}
Index.load = (store) => {
    return store.dispatch(getIndexList())
}
export default connect(
    state => ({list:state.index.list}),
    {getIndexList}
)(Index)