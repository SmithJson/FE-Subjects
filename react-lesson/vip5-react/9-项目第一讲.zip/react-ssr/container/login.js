import React from 'react'
const Login = () =>{
    return (
        <div>
            <h1>登录</h1>
            <div>
                <input type="text"/>
            </div>
        </div>
    )
}
export default Login