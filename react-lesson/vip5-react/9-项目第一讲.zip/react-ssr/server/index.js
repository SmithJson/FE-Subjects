import express from 'express'
import React from 'react'
import {renderToString} from 'react-dom/server' // 专门在server端使用的
import {StaticRouter} from 'react-router-dom'
import {Provider} from 'react-redux'
import {getStore} from '../store/store'
import {Route,Link} from 'react-router-dom'
import {matchRoutes} from 'react-router-config'
import routers from '../router'
let store = getStore()
let app = express()
app.use(express.static('public'))
app.get('*',function(req,res){
    // 遍历所有的路由 寻找有load方法的
    const matchedRoutes = matchRoutes(routers,req.path)
    let promises = []
    matchedRoutes.forEach(item=>{
        let {load} = item.route.component
        if(load){
            const promise = new Promise((resolve,reject)=>{
                load(store).then(resolve).catch(reject)
            })  
            promises.push(promise)
        }
    })
    Promise.all(promises).then(()=>{
        let content = renderToString(
            <Provider store={store}>
                <StaticRouter>
                    <div>
                        <Link to="/">首页</Link>
                        <Link to="/login">登录</Link>
                    </div>
                    {routers.map(route=><Route {...route}/>)}
                </StaticRouter>
            </Provider>
            
        )
        const html = `
            <html>
                <head>
                    <title>软谋教育</title>
                </head>
                <body>
                    <div id="root">${content}</div>
                    <script>
                        window._context = ${JSON.stringify(store.getState())}
                    </script>
                    <script src="/main.js"></script>
                </body>
            </html>
        `
        res.send(html)
    })
    

    
})

app.listen(1000,()=>{console.log('监听1000端口成功');
})