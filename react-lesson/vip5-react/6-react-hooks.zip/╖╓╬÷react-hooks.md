# why?
1. 纯函数组件没有状态
2. 没有生命周期
3. 没有this
# React hooks
组件尽量写成纯函数组件 需要其他的功能就用勾子 勾进来 加强版的纯函数组件

# useState

# useContext()
做状态之间的共享
# useReducer()

# useEffect()