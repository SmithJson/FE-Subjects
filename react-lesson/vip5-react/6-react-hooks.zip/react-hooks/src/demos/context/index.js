import React from 'react'
import PropTypes from 'prop-types'
class ContextDemo extends React.Component {
    // getChildContext
    state={
        newContext:'createContext'
    }
    getChildContext(){
        return {value:this.state.newContext}
    }
  render() {
      const {newContext} = this.state
    return (
            <div>
                <div>
                    <label>childContent</label>
                    <input type="text" value={newContext} onChange={e=>this.setState({newContext:e.target.value})}/>
                </div>
                <Son />
            </div>
    )
  }
}
class Son extends React.Component{
    render(){
        return <div>
            <p>children:{this.context.value}</p>
        </div>
    }
}
Son.contextTypes = {
    value:PropTypes.string
}
ContextDemo.childContextTypes = {
    value:PropTypes.string
}
export default () => 
  <ContextDemo >
  
  </ContextDemo>

