import React from 'react'
import { Route } from 'react-router-dom'

import RefDeom from './demos/ref'
import Context from './demos/context'
import fordwordRef from './demos/forwordRef'
import UseState from './demos/useState'
import UseContext from './demos/useContext'
export default (
  <div>
    <Route path="/ref" component={RefDeom} />
    <Route path="/context" component={Context} />
    <Route path="/forwordRef" component={fordwordRef} />
    <Route path="/useState" component={UseState} />
    <Route path="/useContext" component={UseContext} />
  </div>
)
