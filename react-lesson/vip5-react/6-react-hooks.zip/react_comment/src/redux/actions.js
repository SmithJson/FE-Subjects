import {
    ADD_COMMENT,
    DELETE_COMMENT,
    RECEIVE_COMMENT
} from './action-types'

export const addComment = (comment)=>({type:ADD_COMMENT,data:comment})
export const deleteComment = (index)=>({type:DELETE_COMMENT,data:index})
const receiveComments = (comments)=>({type:RECEIVE_COMMENT,data:comments})
export const getComments = ()=>{
    return dispatch=>{
        setTimeout(()=>{
            const comments = [
                {
                    username:'张三',
                    content:'ReactJS太简单了',
                    id:Date.now()
                },
                {
                    username:'李四',
                    content:'ReactJS太难了',
                    id:Date.now()+1
                },
            ]
            dispatch(receiveComments(comments))
        },1000)
    }
}