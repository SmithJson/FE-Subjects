import React from 'react'
import CommentItem from '../comment-item/comment-item'
import {connect} from 'react-redux'
import './commentList.css'

class CommentList extends React.Component {

  render () {
    let comments = this.props.comments
    console.log(comments);
    
    let display = comments.length > 0 ? 'none' : 'block'
    return (
      <div className="col-md-8">
        <h3 className="reply">评论回复：</h3>
        <h2 style={{display}}>暂无评论，点击左侧添加评论！！！</h2>
        <ul className="list-group">
          {
            comments && comments.map((comment,index)=>{
              return <CommentItem comment={comment} key={index} index={index}/>
            })
          }
          
        </ul>
      </div>
    )
  }
}

export default connect(
  state => ({comments:state.comments})
)(CommentList)