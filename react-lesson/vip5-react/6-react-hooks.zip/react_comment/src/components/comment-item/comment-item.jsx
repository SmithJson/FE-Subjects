import React from 'react'
import './commentItem.css'
import {connect} from 'react-redux'
import {deleteComment} from '../../redux/actions'
class CommentItem extends React.Component {
  handelDeleteComment = () =>{
    const username = this.props.comment.username
    if(window.confirm(`确定删除${username}的评论吗?`)){
      this.props.deleteComment(this.props.index)
    }
  }
  render() {
    let comment = this.props.comment
    return (
      <li className="list-group-item">
        <div className="handle">
          <a href="javascript:" onClick={this.handelDeleteComment}>删除</a>
        </div>
        <p className="user"><span>{comment.username}</span><span>说:</span></p>
        <p className="centence">{comment.content}</p>
      </li>
    )
  }
}

export default connect(
  null,
  {
    deleteComment
  }
)(CommentItem)
