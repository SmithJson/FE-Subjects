import React from 'react'
import {connect} from 'react-redux'
import {addComment} from '../../redux/actions'
class CommentAdd extends React.Component {
  state = {
    username:'',
    content:''
  }
  handelChangeUser = (e)=>{
    this.setState({
      username:e.target.value
    })
  }
  handelChangeCon = (e)=>{
    this.setState({
      content:e.target.value
    })
  }
  handelCommit = ()=>{
    const {content,username} = this.state
    const comment = {username,content}
    // 添加进去 添加的方法从哪里来？？？
    this.props.addComment(comment)
    // 清除输入的数据
    this.setState({
      username:'',
      content:''
    })
  }
  render () {
    const {username,content} = this.state
    return (
      <div className="col-md-4">
        <form className="form-horizontal">
          <div className="form-group">
            <label>用户名</label>
            <input type="text" className="form-control" placeholder="用户名" value={username} onChange={this.handelChangeUser}/>
          </div>
          <div className="form-group">
            <label>评论内容</label>
            <textarea className="form-control" rows="6" placeholder="评论内容" value={content} onChange={this.handelChangeCon}></textarea>
          </div>
          <div className="form-group">
            <div className="col-sm-offset-2 col-sm-10">
              <button type="button" className="btn btn-default pull-right" onClick={this.handelCommit}>提交</button>
            </div>
          </div>
        </form>
      </div>
    )
  }
}
export default connect(
  null,
  {addComment}
)(CommentAdd)