import React from 'react'
import {NavLink,Link,Route,Redirect,Switch} from 'react-router-dom'
import MessageDetail from './messageDetail'
class Message extends React.Component {
    state = {
        messages:[]
    }
    componentDidMount(){
        setTimeout(()=>{
            const messages = [
                {id:1,title:'m1'},
                {id:2,title:'m2'},
                {id:3,title:'m3'},
            ]
            this.setState({
                messages
            })
        },1000)
    }
    render () {
        const {messages} = this.state
        const show = messages.length ? 'none' : 'block'
        return (
            <div>
                <p style={{display:show}}>loading.......</p>
                <ul>
                    {
                        messages && messages.map((item,index)=>{
                            return (
                                <li key={index}>
                                    <Link to={`/home/message/${item.id}`}>{item.title}</Link>
                                </li>
                            )
                        })
                    }
                </ul>
                <Route path="/home/message/:id" component={MessageDetail}></Route>
            </div>
        )
    }
}

export default Message