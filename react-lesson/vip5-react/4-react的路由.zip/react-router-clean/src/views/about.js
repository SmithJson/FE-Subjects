import React from 'react'
export default function About() {
  return (
    <div>
      <h2>About组件内容</h2>
      <div>
        about组件
      </div>
    </div>
  )
}