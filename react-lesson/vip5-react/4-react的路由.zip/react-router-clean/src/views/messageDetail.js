import React from 'react'
const messageDetails = [
    {id:1,title:'详细信息1',content:'我爱你祖国'},
    {id:2,title:'详细信息2',content:'我爱你父母'},
    {id:3,title:'详细信息3',content:'我爱你老婆'},
]
export default function MessageDetail(props) {
    const id = props.match.params.id
    const md = messageDetails.find(md=>md.id == id)
    console.log(md);
    
    // 拿到二级路由穿过来的id值 进行匹配
  return (
    <div>
      <ul>
        <li>id:{md.id}</li>
        <li>title:{md.title}</li>
        <li>content:{md.content}</li>
      </ul>
    </div>
  )
}