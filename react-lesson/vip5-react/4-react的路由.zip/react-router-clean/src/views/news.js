import React from 'react'
class News extends React.Component {
    state = {
        newsArr:['news001','news002','news003']
    }
  render () {
      const {newsArr} = this.state
    return (
        newsArr &&newsArr.map((item,index)=><li key={index}>{item}</li>)
    )
  }
}

export default News