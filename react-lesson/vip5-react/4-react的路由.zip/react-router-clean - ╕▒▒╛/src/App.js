import React from 'react'
class App extends React.Component {
  render () {
    return (
      <div>
        <div className="row">
          <div className="col-xs-offset-2 col-xs-8">
            <div className="page-header">
              <h2>React 路由案例</h2>
            </div>
          </div>
        </div>

        <div className="row">
          <div className="col-xs-2 col-xs-offset-2">
            <div className="list-group">
              {/*导航路由链接*/}
              <a className="list-group-item">About</a>
              <a className="list-group-item">Home</a>
            </div>
          </div>
          <div className="col-xs-6">
            <div className="panel">
              <div className="panel-body">
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
}

export default App