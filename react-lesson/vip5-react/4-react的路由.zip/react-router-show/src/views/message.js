import React from 'react'
import {Link, Route} from 'react-router-dom'
import MessageDetail from "./messageDetail"

export default class Message extends React.Component {
  state = {
    messages: []
  }

  componentDidMount () {
    // 模拟发送ajax请求
    setTimeout(() => {
      const data = [
        {id: 1, title: 'Message001'},
        {id: 2, title: 'Message002'},
        {id: 3, title: 'Message003'},
      ]
      this.setState({
        messages: data
      })
    }, 1000)
  }

  

  render () {
    const path = this.props.match.path
    // console.log(path)
    const {messages} = this.state;
    const show = messages.length ? 'none' : 'block'
    return (
      <div>
        <p style={{display:show}}>loading...........</p>
        <ul>
          {
            messages.map((m, index) => {
              return (
                <li key={index}>
                  {/* <Link to={`${path}/${m.id}`}>{m.title}</Link> */}
                  
                  <Link to={`/home/message/${m.id}`}>{m.title}</Link>
                 
                </li>
              )
            })
          }
        </ul>
        <Route path={`/home/message/:id`} component={MessageDetail}></Route>
      </div>
    )
  }
}