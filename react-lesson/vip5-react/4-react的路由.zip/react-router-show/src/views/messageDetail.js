import React from 'react'

const messageDetails = [
  {id: '1', title: '信息1', content: '我爱你, 祖国'},
  {id: '2', title: '信息2', content: '我爱你, 父母'},
  {id: '3', title: '信息3', content: '我爱你, 老婆'},
]

export default function MessageDetail(props) {

  const id = props.match.params.id
  const md = messageDetails.find(md => md.id===id)

  return (
    <ul>
      <li>ID: {md.id}</li>
      <li>TITLE: {md.title}</li>
      <li>CONTENT: {md.content}</li>
    </ul>
  )
}