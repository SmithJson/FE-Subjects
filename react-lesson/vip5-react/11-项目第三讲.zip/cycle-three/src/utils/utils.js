export default {
    formateDate(time){
        if(!time) return '';
        let date = new Date(time)
        return date.getFullYear() + '-' + (date.getMonth()+1).toString().padStart(2,'0')+'-'+date.getDate().toString().padStart(2,'0')+'  '+date.getHours().toString().padStart(2,'0')+':'+date.getMinutes().toString().padStart(2,'0')+':'+date.getSeconds().toString().padStart(2,'0') 
    },
    pagination(data,callback){
        return {
            onChange:(current)=>{
                callback(current)
            },
            current:data.result.page,
            pageSize:data.result.page_size,
            total:data.result.total_count,
            showQuickJumper:true,
            showTotal:()=>{
                return `一共${data.result.total_count}条`
            }
        }
    }
}
