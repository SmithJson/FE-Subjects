import React from 'react';
import './index.less'
class Home extends React.Component{
  render(){
    return(
         <div className="home-wrap">
            欢迎学习单车后台管理系统
         </div>
    )
  }
}

export default Home;
