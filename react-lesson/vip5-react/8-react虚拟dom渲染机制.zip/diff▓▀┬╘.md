+ domdiff算法解析
    + diff策略
        - dom节点跨层级的操作比较少
        - 拥有相同类的两个组件会生成相似的树形结构 不同的类组件会生成不同的树形结构
        - 同一层级的一组子节点 可以通过uuid进行区分
    + diff 粒度
        + tree diff 
            - 对树的每一层进行遍历 如果组件不存在了 会直接删除
        + Component diff
            - 同一类型的组件 继续比较下去 是否需要比较 -> shouldComponentUpdate
            - 不同类型的组件 直接替换
        + Element diff
            - 常见的类型就是列表
            - 比较策略就是 uuid 遍历一遍 确定要删除的和要更新的
            - uuid一般不要设置成数组的index

ReactElement 用来承载信息的容器 
1. type 类型 用于判断如何创建节点
2. key 和 ref 
3. props 新的属性内容
4. $$typeof 用于确定是否属于 ReactElement