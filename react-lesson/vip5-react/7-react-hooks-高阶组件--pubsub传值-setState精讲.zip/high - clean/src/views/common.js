import React from 'react'
// 传入一个组件 返回一个新的组件
export default (HighComponent) => {
    class NewComponent extends React.Component{
        render(){
            return(
                <div>
                    <p>我是公共的头部</p>
                    <HighComponent />
                    <p>我是公共的底部</p>
                </div>
            )
        }
    }

    return NewComponent
}