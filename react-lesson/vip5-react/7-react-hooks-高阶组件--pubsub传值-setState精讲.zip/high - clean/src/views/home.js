import React from 'react'
import High from './common'
class Home extends React.Component{
  render(){
    return(
      <div>
            <h1>
              我是Home的内容
            </h1>
      </div>
    )
  }
}
export default High(Home)