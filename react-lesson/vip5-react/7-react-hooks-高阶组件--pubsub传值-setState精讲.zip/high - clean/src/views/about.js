import React from 'react'
import High from './common'
class About extends React.Component{
  render(){
    return(
      <div>
            <h1>
              我是About的内容
            </h1>
      </div>
    )
  }
}
export default High(About)