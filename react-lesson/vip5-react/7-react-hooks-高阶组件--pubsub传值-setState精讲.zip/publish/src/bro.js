import React from 'react'
import PubSub from 'pubsub-js'
export default class Bro extends React.Component{
    state = {
        value:''
    }

    render(){
        const {value} = this.state
        PubSub.subscribe('SOS',(res,data)=>{
            this.setState({
                value:data
            })
        })
        return (
            <div>
                我接受到了
                <h1>{value}</h1>
            </div>
        )
    }
}