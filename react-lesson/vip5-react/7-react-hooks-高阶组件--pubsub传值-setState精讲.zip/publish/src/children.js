import React from 'react'
import PubSub from 'pubsub-js'
export default class Children extends React.Component{
    state = {
        value:''
    }
    handelChange = (e) =>{
        this.setState({
            value:e.target.value
        })
    }
    send = () =>{
        const {value} = this.state
        PubSub.publish('SOS',value)
    }
    render(){
        const {value} = this.state
        return (
            <div>
                <input type="text" value={value} onChange={this.handelChange}/>
                <button onClick={this.send}>发送</button>
            </div>
        )
    }
}