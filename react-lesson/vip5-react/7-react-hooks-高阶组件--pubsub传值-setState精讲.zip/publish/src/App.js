import React from 'react'
import Children from './children'
import Bro from './bro'
class App extends React.Component {
  render () {
    return (
      <div>
        <div className="row">
          <div className="col-xs-offset-2 col-xs-8">
            <div className="page-header">
              <h2>React 路由案例</h2>
            </div>
            <Children/>
            <hr/>
            <Bro/>
          </div>
        </div>
      </div>
    )
  }
}

export default App