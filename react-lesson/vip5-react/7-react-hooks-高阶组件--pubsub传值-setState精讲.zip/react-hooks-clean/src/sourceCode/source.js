// partialState 部分state
ReactComponent.prototype.setState = function(partialState, callback) {
    invariant(
      typeof partialState === 'object' ||
        typeof partialState === 'function' ||
        partialState == null,
      'setState(...): takes an object of state variables to update or a ' +
        'function which returns an object of state variables.',
    );
    this.updater.enqueueSetState(this, partialState);
    if (callback) {
      this.updater.enqueueCallback(this, callback, 'setState');
    }
  };
   enqueueSetState: function(publicInstance, partialState) {
      if (__DEV__) {
        ReactInstrumentation.debugTool.onSetState();
        warning(
          partialState != null,
          'setState(...): You passed an undefined or null state object; ' +
            'instead, use forceUpdate().',
        );
      }
  
      var internalInstance = getInternalInstanceReadyForUpdate(
        publicInstance,
        'setState',
      );
  
      if (!internalInstance) {
        return;
      }
  
      var queue =
        internalInstance._pendingStateQueue ||
        (internalInstance._pendingStateQueue = []);
      queue.push(partialState);
      enqueueUpdate(internalInstance);
    }
    
    // 通过enqueueUpdate执行state的更新
  function enqueueUpdate(component) {
    ensureInjected();
    // batchingStrategy批量更新的策略 
    // isBatchingUpdates是否处于批量更新 最开始是默认false
    if (!batchingStrategy.isBatchingUpdates) {
      batchingStrategy.batchedUpdates(enqueueUpdate, component);
      return;
    }
    // 如果isBatchingUpdates为true的话 不进行state的更新操作 而是将需要更新的component添加到dirtyComponents数组中去
    dirtyComponents.push(component);
    if (component._updateBatchNumber == null) {
      component._updateBatchNumber = updateBatchNumber + 1;
    }
  }
  // _pendingStateQueue
  // 会调用updateComponent方法
  performUpdateIfNecessary: function(transaction) {
      if (this._pendingElement != null) {
        ReactReconciler.receiveComponent(
          this,
          this._pendingElement,
          transaction,
          this._context,
        );
      } else if (this._pendingStateQueue !== null || this._pendingForceUpdate) {
        this.updateComponent(
          transaction,
          this._currentElement,
          this._currentElement,
          this._context,
          this._context,
        );
      } else {
        this._updateBatchNumber = null;
      }
    }

  if (!batchingStrategy.isBatchingUpdates) {
      batchingStrategy.batchedUpdates(enqueueUpdate, component);
      return;
    }
  dirtyComponents.push(component);
  if (component._updateBatchNumber == null) {
      component._updateBatchNumber = updateBatchNumber + 1;
    }

  var ReactDefaultBatchingStrategy = {
    isBatchingUpdates: false,
    batchedUpdates: function(callback, a, b, c, d, e) {
      var alreadyBatchingUpdates = ReactDefaultBatchingStrategy.isBatchingUpdates;
      ReactDefaultBatchingStrategy.isBatchingUpdates = true;
      if (alreadyBatchingUpdates) {
        return callback(a, b, c, d, e);
      } else {
        return transaction.perform(callback, null, a, b, c, d, e);
      }
    }
}




{   // 会检测组件中的state和props是否发生变化，有变化才会进行更新; 
    // 如果shouldUpdateComponent函数中返回false则不会执行组件的更新
    updateComponent: function(transaction,
        prevParentElement,
        nextParentElement,
        prevUnmaskedContext,
        nextUnmaskedContext,) {
var inst = this._instance;
var nextState = this._processPendingState(nextProps, nextContext);
var shouldUpdate = true;

if (!this._pendingForceUpdate) {
if (inst.shouldComponentUpdate) {
if (__DEV__) {
shouldUpdate = measureLifeCyclePerf(
     () => inst.shouldComponentUpdate(nextProps, nextState, nextContext),
     this._debugID,
     'shouldComponentUpdate',
);
} else {
shouldUpdate = inst.shouldComponentUpdate(
     nextProps,
     nextState,
     nextContext,
);
}
} else {
if (this._compositeType === CompositeTypes.PureClass) {
shouldUpdate =
     !shallowEqual(prevProps, nextProps) ||
     !shallowEqual(inst.state, nextState);
}
}
}

},
// 该方法会合并需要更新的state，然后加入到更新队列中
_processPendingState: function(props, context) {
var inst = this._instance;
var queue = this._pendingStateQueue;  
var replace = this._pendingReplaceState;
this._pendingReplaceState = false; 
this._pendingStateQueue = null;

if (!queue) {
return inst.state;
}

if (replace && queue.length === 1) {
return queue[0];
}

var nextState = Object.assign({}, replace ? queue[0] : inst.state);
for (var i = replace ? 1 : 0; i < queue.length; i++) {
var partial = queue[i];
Object.assign(
nextState,
typeof partial === 'function'
     ? partial.call(inst, nextState, props, context)
     : partial,
);
}

return nextState;
}
};