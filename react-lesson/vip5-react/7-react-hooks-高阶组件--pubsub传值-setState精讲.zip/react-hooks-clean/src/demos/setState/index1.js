import React from 'react'
export default class SetState extends React.Component{
    state = {
        count:0
    }
    // handelIncrement = () =>{
    //     this.setState({
    //         count:this.state.count + 1
    //     })
    // }
    handelIncrement = () =>{
        this.setState((pre)=>{
            return {count:pre.count + 1}
        })
    }
    handelAdd = ()=>{
        this.handelIncrement()
        this.handelIncrement()
        this.handelIncrement()
    }
    render(){
        const {count} = this.state
        return <div>
            {count}
            <button onClick={this.handelAdd}>添加</button>
        </div>
    }
}