import React from 'react'
export default class SetState extends React.Component{
    state = {
        count:0
    }
    // componentDidMount(){
    //     this.setState({
    //         count:this.state.count + 1
    //     })
    // }
    componentWillMount(){
        this.setState({
            count:this.state.count + 1
        })
    }
    // componet
    render(){
        console.log(123);
        
        return <div>
           123
        </div>
    }
}