import React from 'react'
export default class SetState extends React.Component{
    state = {
        val:0
    }
    componentDidMount(){
        this.setState({val:this.state.val+1})
        console.log(this.state.val); // 0
        this.setState({val:this.state.val+1})
        console.log(this.state.val); // 0
        setTimeout(()=>{
            // 是能够拿到上一次的state的值的 是1
            // 执行 this.setState
            this.setState({val:this.state.val+1})
            console.log(this.state.val); // 2
            this.setState({val:this.state.val+1})
            console.log(this.state.val); // 3
        },0)
    }
    render(){
        return null
    }
}