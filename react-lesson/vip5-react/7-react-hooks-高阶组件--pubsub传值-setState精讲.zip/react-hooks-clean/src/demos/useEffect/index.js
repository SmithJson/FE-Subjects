import React , {useEffect,useState} from 'react'

const UseEffect = ()=>{
    const [loading,setLoading] = useState(true)
    useEffect(()=>{
        setTimeout(()=>{
            setLoading(false)
        },2000)
    })
    return (
        loading ? <p>loading.....</p> : <p>加载完成</p>
    )
}

export default UseEffect