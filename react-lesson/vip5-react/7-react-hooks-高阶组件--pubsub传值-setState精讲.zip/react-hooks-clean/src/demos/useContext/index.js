import React , {useContext} from 'react'

const UseContext = ()=>{
    
    const UseContextCon = React.createContext({})
    const Son = () =>{
        const {name}  = useContext(UseContextCon)
        return (
            <p>我是son组件 我的名字是{name}</p>
        )
    }
    const Child = () =>{
        const {name}  = useContext(UseContextCon)
        return (
            <p>我是child组件 我的名字是{name}</p>
        )
    }
    return (
        <UseContextCon.Provider value={{name:'context'}}>
            <Son />
            <Child/>
        </UseContextCon.Provider>
    )
}

export default UseContext