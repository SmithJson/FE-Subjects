import React from 'react'
export default class NoMatch extends React.Component{
    render(){
        return(
            <div style={{textAlign:'center',fontSize:'20px'}}>
                404 not found !!!!
            </div>
        )
    }
}