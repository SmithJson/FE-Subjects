import React from 'react'
import {HashRouter,Route,Switch} from 'react-router-dom'
import Login from './pages/login'
import App from './app'
import Nomatch from './pages/nomatch'
import routerconfig from './config/menuConfig'
import RouterAuth from './routerAuth'
export default class IRouter extends React.Component{
    render(){
        return (
            <HashRouter>
                <App>
                    <Switch>
                        <Route path="/login" component={Login}></Route>
                        <Route path="/404" component={Nomatch}></Route>
                        <Switch>
                            <RouterAuth config={routerconfig}></RouterAuth>
                        </Switch>
                    </Switch>
                </App>
            </HashRouter>
        )
    }
}