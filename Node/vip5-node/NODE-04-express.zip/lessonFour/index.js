const express = require('express');
const cors = require('cors'); 
const path = require('path');
const app = express();
// /* 自己封装跨域中间件 */
// app.use('*',function (req, res, next) {
//     res.header('Access-Control-Allow-Origin', '*'); //这个表示任意域名都可以访问，这样写不能携带cookie了。
//    //res.header('Access-Control-Allow-Origin', 'http://www.baidu.com'); //这样写，只有www.baidu.com 可以访问。
//     res.header('Access-Control-Allow-Headers', 'Content-Type, Content-Length, Authorization, Accept, X-Requested-With , yourHeaderFeild');
//    res.header('Access-Control-Allow-Methods', 'PUT, POST, GET, DELETE, OPTIONS');//设置方法
//     if (req.method == 'OPTIONS') {
//       res.send(200); // 意思是，在正常的请求之前，会发送一个验证，是否可以请求。
//     }
//     else {
//       next();
//     }
//   });
  //使用cors跨域中间件
app.use(cors());
var birds = require('./routers/birds.js');
// app.Method(path,hander)
// METHOD: get,post,delete,put
//path : 路由
//hander：匹配到路由时 执行函数

// Express 在静态目录查找文件，因此，存放静态文件的目录名不会出现在 URL 中。
// 如果要使用多个静态资源目录，请多次调用 express.static 中间件函数
// http://localhost:3003/index.html
app.use(express.static('public'))
app.use(express.static('public2'))

// 静态函数，为静态目录指定一个挂载路径，如下所示
// app.use('/static', express.static(path.join(__dirname, 'public'))); 
app.use('/html', express.static(path.join(__dirname, 'html'))); 
//访问的链接 ：http://localhost:3003/html/index.html


app.get('/', (req, res) => res.send('Hello World!'))

// app.post('/info', (req, res)=>{
//     res.send('Hello World!')

// })
// app.get('/info', (req, res)=>{
//     res.send('Hello World!')

// })
// app.delete('/info', (req, res)=>{
//     res.send('Hello World!')

// })
// app.put('/info', (req, res)=>{
//     res.send('Hello World!')

// })
app.use('/birds', birds);
app.route('/info')
  .get(function (req, res) {
    res.send('Get a random book')
  })
  .post(function (req, res) {
    res.send('Add a book')
  })
  .put(function (req, res) {
    res.send('Update the book')
  })


app.listen(3003, () => console.log('Example app listening on port 3003!'))