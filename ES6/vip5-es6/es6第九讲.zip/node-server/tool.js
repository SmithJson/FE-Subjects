module.exports = {
    name:[
        {id:1,name:'张飞'},
        {id:2,name:'关羽'},
        {id:3,name:'吕布'},
    ],
    wepon:[
        {id:1,name:'丈八蛇矛枪'},
        {id:2,name:'青龙偃月刀'},
        {id:3,name:'方天画戟'},
    ]
}