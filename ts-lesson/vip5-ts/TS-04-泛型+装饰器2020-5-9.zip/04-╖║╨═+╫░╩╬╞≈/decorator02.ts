

namespace DEC01 {

    function logProperty(param:string){
        console.log(param) //  ruanmou.com
        // 传入下列2个参数：
        // 1、对于静态成员来说是类的构造函数，对于实例成员是类的原型对象。
        // 2、成员的名字。

        return function(target:any,attr:any){
             //target 类HttpClient的原型对象
            console.log(target)
 
            console.log(attr)   // attr 使用装饰器的那个属性  ：url
            target[attr]  = param;
        }
    }

    class HttpClient {
        //静态属性
        @logProperty('50')
        static age:string|undefined;
        @logProperty('ruanmou.com')
        public url:any |undefined;
        @logProperty('laney')
        public name:string | undefined;
        constructor(str:string){
        }
        getData(){
            console.log(this.url);
        }
        say(){
            console.log(this.name);
        }
    }


    var r1:any = new HttpClient('aa');
    console.log(r1.url)
    console.log(r1.name)
    console.log('age:'+HttpClient.age)

}


