

function getData1(value:string):string {
    return value;
}

function getData2(value:number):number {
    return value;
}

//any 放弃了类型检查，传入的参数类型和返回参数类型不一致
function getData3(value:any):any {
    return value;
}

// T表示泛型：具体什么类型是调用这个方法的时候决定的
//泛型函数
function getData<T>(value:T):T {
    return value;
}

var p1 = getData<number>(123);
// getData<number>('123'); //错误
var p2 = getData<string>('123');
