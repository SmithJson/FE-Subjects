// 访问器装饰器

function configable(value:boolean){
// 1. 对于静态成员来说是类的构造函数，对于实例成员是类的原型对象。
// 2. 成员的名字。
// 3. 成员的属性描述符。

    return function(target: any, propertyKey: string, desc: PropertyDescriptor){
        desc.configurable = value;
        desc.enumerable = value;
        //访问器属性：可以起到保护的作用
    }
}
class Point {
    private _x: number;
    private _y: number;
    constructor(x: number, y: number) {
        this._x = x;
        this._y = y;
    }

    @configable(false)
    get XX() {
        return this._x;
    }
    @configable(false)
    get YY(){
        return this._y;
    }
}