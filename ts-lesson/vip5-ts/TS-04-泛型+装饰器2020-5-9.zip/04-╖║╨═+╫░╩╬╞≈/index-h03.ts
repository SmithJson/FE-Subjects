namespace Basic {
    //函数声明
    function fun5<A>(name:A):A{    
        return name
    }

    //函数表达式
    var fun2 = function<T>(name:T):T{
        return name;
    }

    //ES6 
    var fun3 = <T>(name:T)=>name;
}

//规范
interface ConfigFn{
    (value1:string,value2:string):string;
}
var setData:ConfigFn=function(value1:string,value2:string):string{
    return value1+value2;
}
setData('name','张三');


//泛型接口1  ,对接口进行定义，实现接口的时候按照接口的定义传参

namespace HX02 {

    //定义泛型接口
    interface ConfigFn<T>{
        (value1:T):T;
    }

    var setData:ConfigFn<string>= function<T>(value1:T):T{
        return value1
    }
    var s1 = setData('张三');
    console.log(s1);

//   number
    var setData2:ConfigFn<number>= function<T>(value1:T):T{
        return value1
    }
    var s2 = setData2(12);
    console.log(s2);
}

namespace HX03 {

    //定义泛型函数
    interface ConfigFn{
        <T>(value1:T):T;
    }

    var setData:ConfigFn= function<T>(value1:T):T{
        return value1
    }

    var s1 = setData<string>('Alice');
    console.log(s1);

    var s2 = setData<number>(30);
    console.log(s2);

}


interface Search {
    <T>(a:T,b:T):boolean
}

let f4:Search = function<T>(a:T,b:T):boolean{
    return a==b
}

var re= f4<number>(123,123);

console.log(re)


var re2= f4<string>('123','123');
console.log(re2)







