//下面这个只能支持数字类型
class MinClass{
    public list:number[]=[];
    add(num:number){
        this.list.push(num)
    }
    min():number{
        // var minNum = Math.min(...this.list)
        //因为要比较数字 和 字符串，所以用下面的方法

        var minNum=this.list[0];
        for(var i=0;i<this.list.length;i++){
            if(minNum>this.list[i]){
                minNum=this.list[i];
            }
        }
        return minNum;
    }
}

// var m = new MinClass();
// m.add(20);
// m.add(30);
// m.add(10);
// alert(m.min())

//泛型类

namespace HX2 {
    class MinClass<T>{
        public list:T[]=[];
        add(num:T){
            this.list.push(num)
        }
        min():T{
            // var minNum = Math.min(...this.list)
            //因为要比较数字 和 字符串，所以用下面的方法
    
            var minNum=this.list[0];
            for(var i=0;i<this.list.length;i++){
                if(minNum>this.list[i]){
                    minNum=this.list[i];
                }
            }
            return minNum;
        }
    }

//实例化 指定类的T 代表的类型是 number
    var m = new MinClass<number>();
    m.add(20);
    m.add(30);
    m.add(10);
    alert(m.min())

//实例化 指定类的T 代表的类型是 string
var m2 = new MinClass<string>();
    m2.add('b');
    m2.add('a');
    m2.add('m');
    alert(m2.min())

}