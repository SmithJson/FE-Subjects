"use strict";
function getData1(value) {
    return value;
}
function getData2(value) {
    return value;
}
//any 放弃了类型检查，传入的参数类型和返回参数类型不一致
function getData3(value) {
    return value;
}
// T表示泛型：具体什么类型是调用这个方法的时候决定的
//泛型函数
function getData(value) {
    return value;
}
var p1 = getData(123);
// getData<number>('123'); //错误
var p2 = getData('123');
