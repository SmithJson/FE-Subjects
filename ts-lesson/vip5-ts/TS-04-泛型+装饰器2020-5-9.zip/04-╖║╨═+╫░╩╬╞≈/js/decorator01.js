"use strict";
// function helloWord(target: any) {
//     console.log('hello Word!');
// }
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
// @helloWord
// class HelloWordClass {
// }
// var p1 = new HelloWordClass();
// console.log(p1);
// 1.1 类装饰器 -普通的装饰器 (无法传参)
var Lc01;
(function (Lc01) {
    function logClass(target) {
        // console.log(target);  //target:当前类  HttpClient
        target.prototype.url = 'baidu.com';
        target.prototype.getData = function () {
            console.log('我是getdata');
        };
    }
    //通过装饰器 在 类HttpClient添加一些属性 和 原型方法
    var HttpClient = /** @class */ (function () {
        function HttpClient() {
        }
        HttpClient = __decorate([
            logClass
        ], HttpClient);
        return HttpClient;
    }());
    var http = new HttpClient();
    // console.log(http)
})(Lc01 || (Lc01 = {}));
var Lc02;
(function (Lc02) {
    function logClass(param) {
        console.log(param); //ruanmou
        return function (target) {
            // console.log(target);  //target:当前类  HttpClient
            console.log(target);
            target.prototype.apiUrl = 'baidu.com';
        };
    }
    var HttpClient = /** @class */ (function () {
        function HttpClient() {
        }
        HttpClient = __decorate([
            logClass('ruanmou')
        ], HttpClient);
        return HttpClient;
    }());
    var http2 = new HttpClient();
    console.log(http2.apiUrl);
})(Lc02 || (Lc02 = {}));
//注意：
var Lc03;
(function (Lc03) {
    function logClass(target) {
        console.log(target);
        return /** @class */ (function (_super) {
            __extends(Test, _super);
            function Test() {
                var _this = _super !== null && _super.apply(this, arguments) || this;
                _this.apiUrl = '我是修改后的数据';
                return _this;
            }
            Test.prototype.getData = function () {
                // this.apiUrl = this.apiUrl;
                console.log(this.apiUrl);
            };
            return Test;
        }(target));
    }
    var HttpClient = /** @class */ (function () {
        function HttpClient() {
            this.apiUrl = '我是构造函数里面的apiurl';
        }
        HttpClient.prototype.getData = function () {
            console.log(this.apiUrl);
        };
        HttpClient = __decorate([
            logClass
        ], HttpClient);
        return HttpClient;
    }());
    var p2 = new HttpClient();
    console.log(p2.apiUrl);
})(Lc03 || (Lc03 = {}));
