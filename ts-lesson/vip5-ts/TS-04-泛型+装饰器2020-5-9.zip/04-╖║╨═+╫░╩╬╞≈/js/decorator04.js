"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var DBM;
(function (DBM) {
    function logParams(params) {
        // 1、对于静态成员来说是类的构造函数，对于实例成员是类的原型对象。
        // 2、方法的名字。
        // 3、参数在函数参数列表中的索引。
        return function (target, methodName, paramsIndex) {
            console.log(params);
            console.log(target);
            console.log(methodName);
            console.log(paramsIndex);
            debugger;
            target.apiUrl = params;
        };
    }
    var HttpClient = /** @class */ (function () {
        function HttpClient() {
        }
        HttpClient.prototype.getData = function (uuid) {
            console.log(uuid);
        };
        __decorate([
            __param(0, logParams("3yteam.com"))
        ], HttpClient.prototype, "getData", null);
        return HttpClient;
    }());
    var http = new HttpClient();
    http.getData(123456);
    console.log(http.apiUrl);
})(DBM || (DBM = {}));
