"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var DEC01;
(function (DEC01) {
    function logProperty(param) {
        console.log(param); //  ruanmou.com
        // 传入下列2个参数：
        // 1、对于静态成员来说是类的构造函数，对于实例成员是类的原型对象。
        // 2、成员的名字。
        return function (target, attr) {
            //target 类HttpClient的原型对象
            console.log(target);
            console.log(attr); // attr 使用装饰器的那个属性  ：url
            target[attr] = param;
        };
    }
    var HttpClient = /** @class */ (function () {
        function HttpClient(str) {
        }
        HttpClient.prototype.getData = function () {
            console.log(this.url);
        };
        HttpClient.prototype.say = function () {
            console.log(this.name);
        };
        __decorate([
            logProperty('ruanmou.com')
        ], HttpClient.prototype, "url", void 0);
        __decorate([
            logProperty('laney')
        ], HttpClient.prototype, "name", void 0);
        __decorate([
            logProperty('50')
        ], HttpClient, "age", void 0);
        return HttpClient;
    }());
    var r1 = new HttpClient('aa');
    console.log(r1.url);
    console.log(r1.name);
    console.log('age:' + HttpClient.age);
})(DEC01 || (DEC01 = {}));
