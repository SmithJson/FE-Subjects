"use strict";
//下面这个只能支持数字类型
var MinClass = /** @class */ (function () {
    function MinClass() {
        this.list = [];
    }
    MinClass.prototype.add = function (num) {
        this.list.push(num);
    };
    MinClass.prototype.min = function () {
        // var minNum = Math.min(...this.list)
        //因为要比较数字 和 字符串，所以用下面的方法
        var minNum = this.list[0];
        for (var i = 0; i < this.list.length; i++) {
            if (minNum > this.list[i]) {
                minNum = this.list[i];
            }
        }
        return minNum;
    };
    return MinClass;
}());
// var m = new MinClass();
// m.add(20);
// m.add(30);
// m.add(10);
// alert(m.min())
//泛型类
var HX2;
(function (HX2) {
    var MinClass = /** @class */ (function () {
        function MinClass() {
            this.list = [];
        }
        MinClass.prototype.add = function (num) {
            this.list.push(num);
        };
        MinClass.prototype.min = function () {
            // var minNum = Math.min(...this.list)
            //因为要比较数字 和 字符串，所以用下面的方法
            var minNum = this.list[0];
            for (var i = 0; i < this.list.length; i++) {
                if (minNum > this.list[i]) {
                    minNum = this.list[i];
                }
            }
            return minNum;
        };
        return MinClass;
    }());
    //实例化 指定类的T 代表的类型是 number
    var m = new MinClass();
    m.add(20);
    m.add(30);
    m.add(10);
    alert(m.min());
    //实例化 指定类的T 代表的类型是 string
    var m2 = new MinClass();
    m2.add('b');
    m2.add('a');
    m2.add('m');
    alert(m2.min());
})(HX2 || (HX2 = {}));
