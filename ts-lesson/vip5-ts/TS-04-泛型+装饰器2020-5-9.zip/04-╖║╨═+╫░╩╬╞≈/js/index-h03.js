"use strict";
var Basic;
(function (Basic) {
    //函数声明
    function fun5(name) {
        return name;
    }
    //函数表达式
    var fun2 = function (name) {
        return name;
    };
    //ES6 
    var fun3 = function (name) { return name; };
})(Basic || (Basic = {}));
var setData = function (value1, value2) {
    return value1 + value2;
};
setData('name', '张三');
//泛型接口1  ,对接口进行定义，实现接口的时候按照接口的定义传参
var HX02;
(function (HX02) {
    var setData = function (value1) {
        return value1;
    };
    var s1 = setData('张三');
    console.log(s1);
    //   number
    var setData2 = function (value1) {
        return value1;
    };
    var s2 = setData2(12);
    console.log(s2);
})(HX02 || (HX02 = {}));
var HX03;
(function (HX03) {
    var setData = function (value1) {
        return value1;
    };
    var s1 = setData('Alice');
    console.log(s1);
    var s2 = setData(30);
    console.log(s2);
})(HX03 || (HX03 = {}));
var f4 = function (a, b) {
    return a == b;
};
var re = f4(123, 123);
console.log(re);
var re2 = f4('123', '123');
console.log(re2);
