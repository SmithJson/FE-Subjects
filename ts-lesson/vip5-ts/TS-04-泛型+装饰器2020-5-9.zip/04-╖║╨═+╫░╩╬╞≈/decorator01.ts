// function helloWord(target: any) {
//     console.log('hello Word!');
// }

// @helloWord
// class HelloWordClass {
    
// }
// var p1 = new HelloWordClass();
// console.log(p1);

// 1.1 类装饰器 -普通的装饰器 (无法传参)

namespace Lc01 {
    
    function logClass(target:any){
        // console.log(target);  //target:当前类  HttpClient
        target.prototype.url = 'baidu.com';
        target.prototype.getData = function(){
            console.log('我是getdata');
        }

    }
    //通过装饰器 在 类HttpClient添加一些属性 和 原型方法
    @logClass
    class HttpClient {
        constructor() {
        } 
    }

    var http = new HttpClient();
    // console.log(http)
}


namespace Lc02 {

    function logClass(param:string){
        console.log(param)  //ruanmou
        
        return function(target:any){
                // console.log(target);  //target:当前类  HttpClient
                console.log(target)
                target.prototype.apiUrl = 'baidu.com';
                
        }   
    }
    @logClass('ruanmou')
    class HttpClient {
        constructor() {
        } 
    }

    var http2:any = new HttpClient();
    console.log(http2.apiUrl)
}


//注意：
namespace Lc03 {
    function logClass(target:any){
        console.log(target);
        return class Test extends target {
            apiUrl:any = '我是修改后的数据'
            getData(){
                // this.apiUrl = this.apiUrl;
                console.log(this.apiUrl);
            }
        }
     }

 @logClass
 class HttpClient {
    public apiUrl:string | undefined;
    constructor() {
        this.apiUrl = '我是构造函数里面的apiurl';
    } 
    getData(){
        console.log(this.apiUrl)
    }
}

var p2 = new HttpClient();
console.log(p2.apiUrl)




}

   

