// typeScript中的函数
//     1、函数的定义
//     2、可选参数
//     3、默认参数
//     4、剩余参数
//     5、函数重载
//     6、类型别名 type
//*******************1、函数的定义********************
//es5定义函数的方法
/*
 //函数声明法
     function run(){
         return 'run';
     }
 //匿名函数
     var run2=function test(){
         return 'run2';
     }
*/
//ts中定义函数的方法
//函数声明法
function run() {
    return 'run';
    // return 123;  //错误
}
function getInfo(str) {
    if (typeof str == 'string') {
        return '我叫' + str;
    }
    else {
        return '我的年龄是' + str;
    }
}
;
alert(getInfo('张三')); // 正确
alert(getInfo(20)); // 正确 
// alert(getInfo(true)); //报错
//*******************6. 类型别名 type******************** 
/* type str= string; //类型别名
var username:str = 'laney';

function fun6(name:str):str{
   return 'hello ' +name;
}
alert(fun6(username))

type abc = string | number[];
type num = number;

function fun7(a:abc):num{
    return a.length;
}

alert(fun7([1,2,3])); */
