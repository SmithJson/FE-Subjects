//*******************布尔类型（boolean）********************
// es5的写法 （正确写法）  ts中（错误写法）
/* var flag=true;
flag=456; */
//  typescript中为了使编写的代码更规范，更有利于维护，增加了类型校验
//  写ts代码必须指定类型
var flag = true;
flag = false; //正确
// flag = 123; //错误
//*******************数字类型（number）********************
/*   var num:number = 123;
  num = 456;
//   num= 'str'; //错误 */
//*******************字符串类型(string)********************   
/* var str:string = 'this is ts';
str = 'hha';
//  str = 123; //错误 */
//*******************数组类型（array）********************  
//  ts中定义数组有两种方式
// var arr=['1','2',1];  //es5定义数组
// 1.第一种定义数组的方式
/* var arr1:number[] = [11,22,33];
var arr2:string[] = ['11','22','33'];
console.log(arr1) */
//2.第二种定义数组的方式
/* var arr3:Array<number> = [11,22,33];
var arr4:Array<string> = ['11','22','33'];

//2.第san种定义数组的方式
var arr5:any[] = [11,'22','33',true]; */
//*******************元组类型（tuple）******************** 
//  属于数组的一种
/* let arrw:[string,number] = ['123',12]
console.log(arrw) */
//*******************任意类型（any）******************** 
/* var num:any = 123;
num = 'str';
num = true;
console.log(num); */
//任意类型的用处
/* var Obox:any = document.getElementById('box');
Obox.style.color='red'; */
//*******************枚举类型（enum）******************** 
//  enum 枚举名{ 
//     标识符[=整型常数], 
//     标识符[=整型常数], 
//     ... 
//     标识符[=整型常数], 
// } ;  
// 比如：星期，  付款状态（0：支付中， 1：支付成功，2：支付失败） 
/* enum Flag {success=1,error=2,'null'=-2}

let s1:Flag = Flag.success;
let s2:Flag = Flag.error;

enum Color{blue,red,ornage};
var a1:Color = Color.blue;
var a2:Color = Color.red;
console.log(a1);
console.log(a2); //如果标识符没有赋值，他的值就是下标 */
/* enum Color2{blue,red=3,ornage};
var a3:Color2 = Color2.red; //3
var a4:Color2 = Color2.ornage;
console.log(a3);
console.log(a4); */
//*******************undefined******************** 
/* var num2:number;
console.log(num2)  //输出：undefined   报错 */
// 定义没有赋值就是undefined
var num;
num = 123;
console.log(num); //输出：undefined  //正确
//*******************null******************** 
var mk;
mk = null;
console.log(mk);
// 一个元素可能是 number类型 可能是null 可能是undefined
var numr;
numr = 123;
console.log(numr); //输出：undefined  //正确
//*******************void类型******************** 
// typescript中的void表示没有任何类型，一般用于定义方法的时候方法没有返回值。
// es5的定义方法
/* function run(){
    console.log('run')
}
run(); */
//表示方法没有返回任何类型
//正确写法
/* function run():void{
    console.log('run')
}
run(); */
// function run2():string{
//     return '123'
//     // console.log('run')
// }
// run2();
//*******************never类型******************** 
// 其他类型 （包括 null 和 undefined）的子类型，代表从不会出现的值。
// 这意味着声明never的变量只能被never类型所赋值。
var a;
a = (function () {
    throw new Error('错误');
})();
