// typeScript中的函数
//     1、函数的定义
//     2、可选参数
//     3、默认参数
//     4、剩余参数
//     5、函数重载
//     6、类型别名 type

//*******************1、函数的定义********************
//es5定义函数的方法
   /*
    //函数声明法
        function run(){
            return 'run';
        }
    //匿名函数
        var run2=function test(){
            return 'run2';
        }
   */

//ts中定义函数的方法
//函数声明法
function run():string{
    return 'run'; 
    // return 123;  //错误
}

//函数表达式
/* var run2=function test():number{
    return 123;
}
alert(run2()); */

// ts中定义方法传参
/* function getInfo(name:string,age:number):string{
  return `${name} ----${age}`;
}

alert(getInfo('alice',20))

//没有返回值的方法
function run3():void{
   console.log('run3')
}
run3() */

//*******************2、可选参数********************

// es5里面方法的实参和行参可以不一样，但是ts中必须一样，如果不一样就需要配置可选参数

// 注意:可选参数必须配置到参数的最后面


/* function getInfo(name:string,age?:number):string{
   
    if(age) {
        return `${name} ----${age}`;
    } else {
        return `${name} ----年龄保密`;
    }
  } */
  
//   alert(getInfo('alice'))
//   alert(getInfo('song',10))

//*******************3、默认参数********************

// es5里面没法设置默认参数，es6和ts中都可以设置默认参数


/* function getInfo(name:string,age:number=20):string{
    return `${name} ----${age}`;
  }

  alert(getInfo('张三'))
  alert(getInfo('李四',10)) */


//*******************4、剩余参数********************

/*  function sum(a:number,b:number,c:number,d:number):number{
        return a+b+c+d;
    }
 alert(sum(1,2,3,4)) ; */


//三点运算符 接受新参传过来的值
// 注意这里： sum 函数的本意是希望你传入多个参数的，所以不能传入一个数据

/* function sum2(...result:number[]):number {

    var sum = 0;
    for(var i=0;i<result.length;i++) {
        sum+= result[i];
    }
     return sum;
}

alert(sum2(1,2,3,4,8,9))  */


/* function sum3(a:number,b:number,...result:number[]):number {

    var sum = a+b;
    for(var i=0;i<result.length;i++) {
        sum+= result[i];
    }
     return sum;
}

// alert(sum3(1,2,3,9))
var arr04:number[] = [3,9,8];
var p2 = sum3(1,2,...arr04)
console.log('p2：'+p2) */

//*******************5. ts函数重载******************** 

/* java中方法的重载：重载指的是两个或者两个以上同名函数，但它们的参数不一样，这时会出现函数重载的情况。
typescript中的重载：通过为同一个函数提供多个函数类型定义来试下多种功能的目的。
ts为了兼容es5 以及 es6 重载的写法和java中有区别。*/


// es5中出现同名方法，下面的会替换上面的方法 
/* function css(config){
}
function css(config,value){
} */

// ts中的重载

function getInfo(name:string):string;
function getInfo(age:number):string;

function getInfo(str:any):any {
    if(typeof str=='string'){
        return '我叫'+str
    } else {
        return '我的年龄是'+str
    }
};

alert(getInfo('张三')); // 正确
alert(getInfo(20)); // 正确 

// alert(getInfo(true)); //报错



//*******************6. 类型别名 type******************** 

/* type str= string; //类型别名
var username:str = 'laney';

function fun6(name:str):str{
   return 'hello ' +name;
}
alert(fun6(username))

type abc = string | number[];
type num = number;

function fun7(a:abc):num{
    return a.length;
}

alert(fun7([1,2,3])); */








