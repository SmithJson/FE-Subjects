export namespace AA {
    export class Animal {
        name:string;
        color:string;
        constructor(name1:string,color:string){
            this.name = name1;
            this.color= color
        }
        eat(){
            console.log('吃肉');
        }
    }
    
    export class Dog extends Animal {
        static likes='喜欢运动';
        weight:string;
        constructor(uname:string,color:string,weight:string) {
            super(uname,color); //关键字， 调用父类构造函数和方法
            this.weight = weight;
        }
        run(){
            console.log('喜欢跑');
        }
    }
}


export namespace BB {
    export class Animal {
        name:string;
        color:string;
        constructor(name1:string,color:string){
            this.name = name1;
            this.color= color
        }
        eat(){
            console.log('吃肉');
        }
    }
    
    export class Cat extends Animal {
        weight:string;
        constructor(uname:string,color:string,weight:string) {
            super(uname,color); //关键字， 调用父类构造函数和方法
            this.weight = weight;
        }
        run(){
            console.log('喜欢吃老鼠');
        }
    }
}