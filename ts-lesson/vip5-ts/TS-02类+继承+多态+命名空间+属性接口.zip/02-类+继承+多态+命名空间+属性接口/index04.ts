// abstract抽象方法只能放在抽象类里面
namespace AbstractFun {
    abstract class Animal{
        public name:string;
        constructor(name:string){
            this.name=name;
        }
        abstract eat():any;  //抽象方法不包含具体实现并且必须在派生类中实现。
        run(){
            console.log('其他方法可以不实现')
        }
    }
    
    // var a = new Animal('猫类') //错误  抽象类不能实例化，
    
    class Dog extends Animal {
        constructor(pname:any){
            super(pname);
        }
       //抽象类的子类必须实现抽象类里面的抽象方法
        eat(){
            console.log(this.name+'吃粮食')
        }
    }
    
    var d = new Dog('小花');
    d.eat();
}
