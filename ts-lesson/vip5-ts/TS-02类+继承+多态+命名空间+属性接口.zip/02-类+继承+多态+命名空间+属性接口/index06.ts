import {AA,BB} from './modules/animal';

var ad1 = new AA.Dog('小狗','白色','10')
console.log(ad1.run())

var ac1 = new BB.Cat('小猫','白色','20')
console.log(ac1.run())