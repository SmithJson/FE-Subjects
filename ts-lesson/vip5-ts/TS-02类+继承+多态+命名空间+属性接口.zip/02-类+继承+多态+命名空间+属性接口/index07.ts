//没有使用接口

/* function print(obj:{ label:string}){
    // console.log(  labelObj.label );
    console.log(obj);
}
 
let myObj={ size:10,label:"Size 10 Object" };

print(myObj);
// print({label:'sss',size:10});  */ 


//使用接口

//接口规范
interface labelVal {
    label:string; 
    size:number
}

// type 别名
type a1 = string; //基础类型
type a2 = string | number; //联合类型
type a3 = [string,number]; //元主类型

type labelObj = {
    label:string; 
    size:number
}

function print(obj:labelVal){
   console.log(obj);
}

let myObj={ size:10,label:"Size 10 Object" };
print(myObj)

//接口就相当于是一种约束，让大家都遵循


function print2(obj:labelObj){
    console.log(obj);
 }

 print2({ size:10,label:"type 别名" })

// 接口： 行为和动作的一个规范，对方法进行约束

