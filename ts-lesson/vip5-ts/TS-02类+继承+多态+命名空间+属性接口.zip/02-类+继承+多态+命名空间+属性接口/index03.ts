//多态:父类定义一个方法不去实现，让继承它的子类去实现  每一个子类有不同的表现 

class Animal {
    name:string;
    color:string;
    constructor(name1:string,color:string){
        this.name = name1;
        this.color= color
    }
    eat(){
       //具体吃什么 ，不知道，具体吃什么?继承它的子类去实现 ，每一个子类的表现不一样
        console.log('吃的方法');
    }
}

class Dog extends Animal {
    static likes='喜欢运动';
    weight:string;
    constructor(weight:string,uname:string,color:string) {
        super(uname,color); //关键字， 调用父类构造函数和方法
        this.weight = weight;
    }
    eat(){
        return this.name +'吃粮食'
    }
}

class Cat extends Animal {
    static likes='喜欢运动';
    weight:string;
    constructor(weight:string,uname:string,color:string) {
        super(uname,color); //关键字， 调用父类构造函数和方法
        this.weight = weight;
    }
    eat(){
        return this.name +'吃老鼠'
    }
}


var dog1 = new Dog('20','小狗','白色');
alert(dog1.eat())


var cat1 = new Cat('20','小猫','黑色');
alert(cat1.eat())

console.log(cat1)