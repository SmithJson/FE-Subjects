//TS的构造函数

/* class Cat {
    name:string;
    color:string;
    constructor(name1:string,color:string){
        this.name = name1;
        this.color= color
    }
    eat(){
        console.log('吃老鼠');
    }
}

var c1 = new Cat('小花','白色');
console.log(c1)
console.log(c1.eat()) */

//继承 extends  super

/* class Animal {
    name:string;
    color:string;
    constructor(name1:string,color:string){
        this.name = name1;
        this.color= color
    }
    eat(){
        console.log('吃肉');
    }
}

class Dog extends Animal {
    static likes='喜欢运动';
    weight:string;
    constructor(weight:string,uname:string,color:string) {
        super(uname,color); //关键字， 调用父类构造函数和方法
        this.weight = weight;
    }
    run(){
        console.log('喜欢跑');
    }
}

var d1 = new Dog('45','小黑','黑色');
d1.eat();
// d1.likes   //报错
console.log(Dog.likes);
console.log(d1); */
