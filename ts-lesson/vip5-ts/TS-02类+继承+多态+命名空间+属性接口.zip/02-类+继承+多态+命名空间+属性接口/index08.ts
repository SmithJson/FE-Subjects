interface FullName{
    firstName:string;   //注意;结束
    secondName:string;
    // secondName?:string; //可选属性，可传可不传
    hello(str:string):string
}

function printName(name:FullName){
    // 必须传入对象  firstName  secondName
    console.log(name.firstName+'--'+name.secondName);
    console.log(name)
}
// printName('1213');  //错误
/*传入的参数必须包含 firstName  secondName*/
var obj={   
    firstName:'张',
    secondName:'三',
    hello(str:string):string{
        return obj.firstName+obj.secondName;
    }
};
printName(obj)