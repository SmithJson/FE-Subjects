/* // 5.修饰属性和方法
class Animal {
    public name:string;  //公共的， 在当前类里面、 子类  、类外面都可以访问
    private color:string;  // 私有的  在当前类里面可以访问，子类、类外部都没法访问
    protected gender:string; //保护类型  在当前类里面、子类里面可以访问 ，在类外部没法访问
    constructor(name1:string,color:string,gender:string){
        this.name = name1;
        this.color= color;
        this.gender = gender;
    }
    public eat(){
        console.log('吃肉------');
        console.log(this.name)  // 公共的 在当前类里面
        console.log(this.color)  // 私有的 在当前类里面
        console.log(this.gender)  // 保护类型 在当前类里面
        console.log('---------');
    }
}

class Dog extends Animal {
    static likes='喜欢运动';
    weight:string;
    constructor(weight:string,uname:string,color:string,gender:string) {
        super(uname,color,gender); //关键字， 调用父类构造函数和方法
        this.weight = weight;
    }
    run(){
        console.log('喜欢跑');
        console.log(this.name)  //public 子类 可以访问
        // console.log(this.color)  //private 子类 不可以访问
        console.log(this.gender)  //protected 子类 可以访问
    }
}

var d1 = new Dog('45','小黑','黑色','男');
d1.eat();
console.log(d1.name)  //public name 类外面都可以访问
// console.log(d1.color)  // private color 类外面不可以访问
// console.log(d1.gender)  // protected color 类外面不可以访问 */