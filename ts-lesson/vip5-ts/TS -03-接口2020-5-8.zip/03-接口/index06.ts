// 6.2 接口可以继承接口

namespace PE1 {
    interface Animal {
        eat(): void;
    }
    interface Female {
        usernmae:string;
    }
    interface Male {
       age:string
    }

    //接口 Person 继承了接口Animal
    //单继承。只继承了一个接口
    interface Person extends Animal {
        work():void;
    }

    //多接口继承
    // 接口名 extends 接口1,接口2,....接口n
    //继承多个接口用逗号分开
    interface Cat extends Animal,Female,Male {
        color:string;
    }

    class webFront implements Person {
        name:string;
        constructor(name:string){
            this.name = name;
        }
        eat(){
            console.log(this.name + '吃西瓜')
        }
        work(){
            console.log(this.name + '写代码')
        }
    }
    var w1 = new webFront('张三');
    w1.eat();

//类继承类并实现接口：  WebFront继承类Programmer 并实现接口Person

}

//类可以实现类， 也可以实现接口

namespace PE2 {
    interface Animal {
        eat(): void;
    }
    interface Person extends Animal {
        work():void;
    }

    class Programer {
        name:string;
        constructor(name:string){
            this.name = name;
        }
        codeing(code:string){
            console.log(this.name +code);
        }
    }

    //类继承类并实现接口,webFront 继承了类Programer ， 并实现了接口Person

    class webFront extends Programer implements Person {
          
        constructor(name:string){
            super(name)
        }
        eat(){
            console.log(this.name + '吃苹果')
        }
        work(){
            console.log(this.name + '写代码')
        }
     }

     var w2 = new webFront('Tony');
     w2.eat();
}


//接口继承类
namespace PE3 {

    class Point {
        x:number;
        y:number;
        constructor(x:number,y:number){
            this.x = x;
            this.y= y;
        }
        shape(){
            console.log('原型');
        }
    }

    interface Point3D extends Point {
        z:number;
        eat(): void;
    }

    var ts:Point3D = {
        x:1,
        y:2,
        z:3,
        shape(){
            console.log('kkkk');
        },
        eat(){
            console.log('喜欢吃水果');
        }
    }

    console.log(ts);
}