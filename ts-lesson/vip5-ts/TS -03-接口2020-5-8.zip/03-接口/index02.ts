//使用接口 ,一种规范
namespace INK1 {
    interface labelValue{
        label:string;
        apple:string;
        // [propName:string]:any;   //添加字符串的索引签名
        // size?:string; //可传可不传
       
    };
    
     function printB(labelObj:labelValue){
        console.log( 'labelObj.label' );
        console.log( labelObj );
     }
    
    //  printB({
    //     label:'你好',
    //     size:10
    //  })

// 第一种断言 ：
     printB({
        label:'你好',
        // size:'10',
        apple:'ddd'
     } as {apple:string;label:string})

//第二种方式：添加字符串的索引签名
    // printB({
    //     label:'你好',
    //     size:10,
    //     age:10
    //  })

   //第三种：将字面量赋值给另外一个变量

    // var obj =  {
    //     label:'你好',
    //     size:10,
    //     age:10
    // }

    // printB(obj)
}


