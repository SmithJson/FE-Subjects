//可索引接口

namespace ArrG {
    interface UserArr{
        [index:number]:string
    }
    //1.对数据的约束
    var  arr1:UserArr = ['aaa','111'];
    // var  arr2:UserArr = ['aaa',111]; //错误
    console.log(arr1[0])


    //2. 对对象的约束
    interface UserObj{
        [index:string]:string
    }

    var obj1:UserObj = {name:"张三"} //正确
    // var obj1:UserObj = {name:112} //错误

   console.log(obj1)
}


