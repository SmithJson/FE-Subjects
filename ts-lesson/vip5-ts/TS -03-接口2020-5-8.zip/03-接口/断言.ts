

function getLength(x:number|string):number{
     return x.toString().length;
    //  return x.length; //错误
}

// 方式一： <类型> 值 
function getLength1(x:number|string):number{
    if((<string>x).length) {
        return (<string>x).length
    } else {
        return x.toString().length
    }
}


// 方式二： 值 as 类型

function getLength2(x:number|string):number{
    if((x as string)) {
        return (x as string).length
    } else {
        return x.toString().length;
    }
 }


//注意：
// 联合类型 ：x:number|string
// 类型断言并非是类型转换，断言一个联合类型中不存在的类型会报错！