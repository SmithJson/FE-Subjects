// 类类型接口用来规范一个类的内容。
// 类实现接口本质上 即类遵循接口的约束，接口里面写了多少个函数、参数，实现的类里面也要写相同的函数、参数。
namespace TT1 {
    interface FullName {  
        username: string;  
    }  

    //WebCoder 需要遵循接口FullName的约束
    class WebCoder implements FullName {
        fruit:string;
        username:string;
        constructor(fruit01:string,username:string) {
            this.fruit = fruit01;
            this.username = username;
        }
    }

    var p1 = new WebCoder('苹果','Alice');
    console.log(p1);

}

namespace TT2 {
    // 可以在接口中描述一个方法，并在类里具体实现它的功能，
    // 如同下面的setName方法一样
    interface FullName {  
        username: string;  
        setName(name:string):void;
        getName():void
    } 

    class Person implements FullName {
        username:string;
        constructor(username:string) {
            this.username = username;
        }
        setName(str:string){
            this.username = str;
        }
        getName(){
            console.log(this.username);
        }
    }

    var p1 = new Person('laney');
    p1.setName('blood');
    p1.getName();
}