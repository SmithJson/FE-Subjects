//函数类型接口：对函数的参数以及返回值进行约束
namespace FunctionA {
    //不使用接口
    var add1 = function(a:number,b:number):number{
        return a+b;
    }

    //使用函数接口
    interface CalcTwo {
        (a:number,b:number):number
    }

   var add2:CalcTwo = function(a1:number,b1:number):number {
        return a1+b1;
   }

    interface encrypt{
        (key:string,value:string):string;
    }
    var md5:encrypt=function(key:string,value:string):string{
          //模拟操作
          return key+value;
    }

    console.log(md5('name','tony'))

}


namespace MathAdd {
    interface CalcTwo {
        (a:number,b:number):number
    }

    /**
     * 计算数组被某种算法运算的结果
     * @param {number[]} arr  数组
     * @param {CalcTwo} calc  用户指定的算法函数
     * @param {number} initVal  传入初始值
     * @returns {number}  得到最终运算结果
    **/

   function calcArr(arr:number[],calc:CalcTwo,initVal:number):number {
        // var result = initVal;
        // arr.forEach((value,index)=>{
        //     result = calc(result,value)  
        // });
        // return result

        // 高阶函数
        return arr.reduce(function(a,b){
            return calc(a,b)  
        },initVal)


   }

   var arr:number[]=[1,3,5,7,9];

   var sum =  function(a1:number,b1:number):number {
        return a1+b1;
    }
    var multipy =  function(a1:number,b1:number):number {
        return a1*b1;
    }
    //相加
    var p1 = calcArr(arr,sum,10);
    console.log('相加:'+p1);

    //相乘
    var p2 = calcArr(arr,multipy,10);
    console.log('相乘:'+p2);

}

