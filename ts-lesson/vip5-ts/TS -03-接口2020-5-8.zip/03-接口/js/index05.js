"use strict";
// 类类型接口用来规范一个类的内容。
// 类实现接口本质上 即类遵循接口的约束，接口里面写了多少个函数、参数，实现的类里面也要写相同的函数、参数。
var TT1;
(function (TT1) {
    //WebCoder 需要遵循接口FullName的约束
    var WebCoder = /** @class */ (function () {
        function WebCoder(fruit01, username) {
            this.fruit = fruit01;
            this.username = username;
        }
        return WebCoder;
    }());
    var p1 = new WebCoder('苹果', 'Alice');
    console.log(p1);
})(TT1 || (TT1 = {}));
var TT2;
(function (TT2) {
    var Person = /** @class */ (function () {
        function Person(username) {
            this.username = username;
        }
        Person.prototype.setName = function (str) {
            this.username = str;
        };
        Person.prototype.getName = function () {
            console.log(this.username);
        };
        return Person;
    }());
    var p1 = new Person('laney');
    p1.setName('blood');
    p1.getName();
})(TT2 || (TT2 = {}));
