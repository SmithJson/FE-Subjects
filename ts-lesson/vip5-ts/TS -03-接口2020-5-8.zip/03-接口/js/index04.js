"use strict";
//可索引接口
var ArrG;
(function (ArrG) {
    //1.对数据的约束
    var arr1 = ['aaa', '111'];
    // var  arr2:UserArr = ['aaa',111]; //错误
    console.log(arr1[0]);
    var obj1 = { name: "张三" }; //正确
    // var obj1:UserObj = {name:112} //错误
    console.log(obj1);
})(ArrG || (ArrG = {}));
