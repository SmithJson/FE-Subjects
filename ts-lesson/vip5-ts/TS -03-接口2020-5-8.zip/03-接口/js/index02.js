"use strict";
//使用接口 ,一种规范
var INK1;
(function (INK1) {
    ;
    function printB(labelObj) {
        console.log('labelObj.label');
        console.log(labelObj);
    }
    //  printB({
    //     label:'你好',
    //     size:10
    //  })
    // 第一种断言 ：
    printB({
        label: '你好',
        // size:'10',
        apple: 'ddd'
    });
    //第二种方式：添加字符串的索引签名
    // printB({
    //     label:'你好',
    //     size:10,
    //     age:10
    //  })
    //第三种：将字面量赋值给另外一个变量
    // var obj =  {
    //     label:'你好',
    //     size:10,
    //     age:10
    // }
    // printB(obj)
})(INK1 || (INK1 = {}));
