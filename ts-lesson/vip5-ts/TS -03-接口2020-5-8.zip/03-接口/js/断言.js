"use strict";
function getLength(x) {
    return x.toString().length;
    //  return x.length; //错误
}
// 方式一： <类型> 值 
function getLength1(x) {
    if (x.length) {
        return x.length;
    }
    else {
        return x.toString().length;
    }
}
// 方式二： 值 as 类型
function getLength2(x) {
    if (x) {
        return x.length;
    }
    else {
        return x.toString().length;
    }
}
//注意：
// 联合类型 ：x:number|string
// 类型断言并非是类型转换，断言一个联合类型中不存在的类型会报错！
