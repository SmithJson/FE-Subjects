"use strict";
function printA(labelObj) {
    console.log(labelObj);
}
printA({
    label: '你好'
});
//错误
// printA({
//     label:'你好',
//     name:'laney'
// })
//跳过额外字段的检测
// 第一种断言 ：
printA({
    label: '你好',
    name: 'laney'
});
//第二种方式：添加字符串的索引签名
function printB(labelObj) {
    console.log(labelObj);
}
printB({
    label: '你好',
    name: 'laney',
    age: 20
});
//第三种：将字面量赋值给另外一个变量
var obj = {
    label: '你好',
    name: 'laney'
};
// printA({
//     label:'你好',
//     name:'laney'
// })
printA(obj);
