"use strict";
// 6.2 接口可以继承接口
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var PE1;
(function (PE1) {
    var webFront = /** @class */ (function () {
        function webFront(name) {
            this.name = name;
        }
        webFront.prototype.eat = function () {
            console.log(this.name + '吃西瓜');
        };
        webFront.prototype.work = function () {
            console.log(this.name + '写代码');
        };
        return webFront;
    }());
    var w1 = new webFront('张三');
    w1.eat();
    //类继承类并实现接口：  WebFront继承类Programmer 并实现接口Person
})(PE1 || (PE1 = {}));
//类可以实现类， 也可以实现接口
var PE2;
(function (PE2) {
    var Programer = /** @class */ (function () {
        function Programer(name) {
            this.name = name;
        }
        Programer.prototype.codeing = function (code) {
            console.log(this.name + code);
        };
        return Programer;
    }());
    //类继承类并实现接口,webFront 继承了类Programer ， 并实现了接口Person
    var webFront = /** @class */ (function (_super) {
        __extends(webFront, _super);
        function webFront(name) {
            return _super.call(this, name) || this;
        }
        webFront.prototype.eat = function () {
            console.log(this.name + '吃苹果');
        };
        webFront.prototype.work = function () {
            console.log(this.name + '写代码');
        };
        return webFront;
    }(Programer));
    var w2 = new webFront('Tony');
    w2.eat();
})(PE2 || (PE2 = {}));
//接口继承类
var PE3;
(function (PE3) {
    var Point = /** @class */ (function () {
        function Point(x, y) {
            this.x = x;
            this.y = y;
        }
        Point.prototype.shape = function () {
            console.log('原型');
        };
        return Point;
    }());
    var ts = {
        x: 1,
        y: 2,
        z: 3,
        shape: function () {
            console.log('kkkk');
        },
        eat: function () {
            console.log('喜欢吃水果');
        }
    };
    console.log(ts);
})(PE3 || (PE3 = {}));
